import { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react'
// projectsRepository: selectors only — no seed
import { ROLES, isAllowed, getProjectRole } from '../domain/permissions'
import { computePhaseProgress } from '../domain/projectAggregates'
import { PROJECT_COLOR_PALETTE } from '../domain/status'
import { api, setInMemoryToken } from '../services/api/client'
import { getSocket, disconnectSocket, onConversationUpdated, offConversationUpdated } from '../services/socket'

// Palette de couleurs projet — sobres, premium, variées
// PRJ-09 : source unique de la palette projet (domain/status.js)
const PROJECT_COLORS = PROJECT_COLOR_PALETTE
const autoProjectColor = (existingProjects) => {
  const used = new Set((existingProjects || []).map(p => p.color).filter(Boolean))
  const available = PROJECT_COLORS.filter(c => !used.has(c))
  return available.length > 0 ? available[0] : PROJECT_COLORS[existingProjects.length % PROJECT_COLORS.length]
}

// Fire-and-forget API sync — doesn't block UI, tracks errors
let _syncErrors = 0
const sync = (promise) => promise.catch(e => {
  _syncErrors++
  console.warn('[MEEREO sync]', e.message)
  // After 3+ consecutive failures, the backend is likely down
  if (_syncErrors >= 3 && typeof window !== 'undefined') {
    console.error('[MEEREO] Backend inaccessible — les données sont sauvées localement.')
  }
}).then(() => { _syncErrors = 0 }) // Reset on success

// Gendered client label — adapts to civilité stored in onboardingData
function clientLabel(store) {
  const c = store.onboardingData?.civilite
  if (c === 'Madame') return 'La cliente'
  if (c === 'Monsieur') return 'Le client'
  return 'Le ou la client(e)'
}

// STORE_KEY kept for legacy cleanup only — no longer written
const STORE_KEY = 'meereo_store_v2'

const defaultStore = {
  _token: null,
  _hydrated: false,
  _checking: true,   // true tant que /auth/me n'a pas répondu — jamais persisté
  _cachedUser: null, // { id, type, name } — hint de session stocké localement pour éviter le flash
  _onboardingByUser: {},
  user: null,
  users: [],
  organizations: [],
  projects: [],
  aos: [],
  offers: [],
  markets: [],
  missions: [],
  assets: [],
  passports: [],
  tasks: [],
  documents: [],
  products: [],
  notifications: [],
  transactions: [],
  activities: [],
  onboardingData: null,
  clients: [],
  intervenants: [],
  contacts: [],
  commandes: [],
  fournisseurs: [],
  notes: [],
  decisions: [],
  paymentRequests: [],
  photos: [],
  taskStates: {},
  lastProjectUpdate: null,
  clientPrefs: { notifEmail: true, notifPush: true, rappels: false, resume: false },
  invitations: [],
  sellerOrders: [],
  connectedIntegrations: [],
  events: [],
  rapportStatuts: {},
  rapports: [],
  reviews: [],
  offerStatuts: {},
  marketStatuts: {},
  deletedEventIds: [],
  eventOverrides: {},
  wallets: [],
  conversations: [],
  // Finance / Fintech
  paymentOrders: [],
  ledgerEntries: [],
  payoutRequests: [],
  proofDocuments: [],
  disputeCases: [],
  commissions: [],        // { id, introductionId, structureId, structureName, projectId, clientId, montantBase, montantCommission, rate, status, createdAt, paidAt }
  introductions: [],      // { id, projectId, clientId, structureId, structureName, metier, status, introDate, retainedAt, source:'meereo_cle_en_main' }
  commissionAcceptances: [], // { userId, acceptedAt } — structures qui ont accepté les CGV commission
  // KAI
  kaiEntitlement: {
    pro: { tier: 'standard', quotaLimit: 25, quotaUsed: 0, goldStartDate: null, goldEndDate: null },
    client: { tier: 'standard', quotaLimit: 25, quotaUsed: 0, goldStartDate: null, goldEndDate: null },
    fournisseur: { tier: 'standard', quotaLimit: 25, quotaUsed: 0, goldStartDate: null, goldEndDate: null },
  },
  kaiOnboardingDone: { pro: false, client: false, fournisseur: false },
  kaiUsage: [],
  kaiConversations: [],
  kaiMemory: [],
  projectInvitations: [],
  clotureRequests: [],
  entrepriseDocs: [],
  aoInvitations: [], // { id, aoId, senderUserId, targetUserId?, targetEmail?, targetPhone?, targetName?, targetTrade, message?, status: sent|opened|signed_up|responded, createdAt }
  // ═══ MULTI-ACTEURS V2 ═══
  projectMembers: [], // { id, projectId, userId, role, joinedAt } — membership formel projet
  _projectsSeeded: false,
}

// ─── Persistance minimale via sessionStorage ─────────────────────────────────
// Seul _onboardingByUser est conservé (wizard en cours avant création de compte).
// Tout le reste est refetché depuis l'API à chaque session (cookie httpOnly).
// sessionStorage est vidé à la fermeture de l'onglet — aucune donnée ne survit
// entre sessions, ce qui est le comportement voulu.
const SESSION_OB_KEY = 'meereo_onboarding_by_user'

function loadFromStorage() {
  // One-time migration: clear old localStorage store key if present
  try { localStorage.removeItem(STORE_KEY) } catch {}
  let cachedUser = null
  try {
    const cu = sessionStorage.getItem('meereo_cached_user')
    if (cu) cachedUser = JSON.parse(cu)
  } catch {}
  try {
    const raw = sessionStorage.getItem(SESSION_OB_KEY)
    if (raw) {
      const parsed = JSON.parse(raw)
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        return { ...defaultStore, _onboardingByUser: parsed, _cachedUser: cachedUser }
      }
    }
  } catch (e) {
    console.warn('MEEREO loadStore error', e)
  }
  return { ...defaultStore, _cachedUser: cachedUser }
}

function saveToStorage(store) {
  try {
    // Only persist onboarding wizard data — everything else comes from the API
    if (store._onboardingByUser && Object.keys(store._onboardingByUser).length > 0) {
      sessionStorage.setItem(SESSION_OB_KEY, JSON.stringify(store._onboardingByUser))
    } else {
      sessionStorage.removeItem(SESSION_OB_KEY)
    }
    // Persist cached user hint so refresh doesn't flash/redirect to onboarding
    if (store._cachedUser) {
      sessionStorage.setItem('meereo_cached_user', JSON.stringify(store._cachedUser))
    } else if (!store.user) {
      sessionStorage.removeItem('meereo_cached_user')
    }
  } catch { /* sessionStorage not available (private mode, quota, etc.) */ }
}

// Merge two arrays by ID — API data (source of truth) overrides local data
function mergeById(localArr, apiArr) {
  const map = new Map()
  ;(localArr || []).forEach(item => { if (item && item.id) map.set(item.id, item) })
  ;(apiArr || []).forEach(item => { if (item && item.id) map.set(item.id, { ...map.get(item.id), ...item }) })
  return Array.from(map.values())
}

const MeereoContext = createContext(null)

/**
 * Transforme le tableau d'entitlements retourné par GET /api/kai/entitlements
 * en les 3 clés du store : kaiEntitlement, kaiOnboardingDone.
 * Accepte aussi conversations + memory pour construire kaiConversations/kaiMemory.
 */
function buildKaiState(entitlements = [], conversations = [], memory = []) {
  const entObj = {
    pro: { tier: 'standard', quotaLimit: 25, quotaUsed: 0, goldStartDate: null, goldEndDate: null },
    client: { tier: 'standard', quotaLimit: 25, quotaUsed: 0, goldStartDate: null, goldEndDate: null },
    fournisseur: { tier: 'standard', quotaLimit: 25, quotaUsed: 0, goldStartDate: null, goldEndDate: null },
  }
  const onboardingDone = { pro: false, client: false, fournisseur: false }
  for (const e of entitlements) {
    if (!['pro', 'client', 'fournisseur'].includes(e.role)) continue
    entObj[e.role] = {
      tier: e.tier || 'standard',
      quotaLimit: e.quotaLimit ?? 25,
      quotaUsed: e.quotaUsed ?? 0,
      goldStartDate: e.goldStartDate || null,
      goldEndDate: e.goldEndDate || null,
    }
    onboardingDone[e.role] = e.onboardingDone ?? false
  }
  return {
    kaiEntitlement: entObj,
    kaiOnboardingDone: onboardingDone,
    kaiConversations: conversations,
    kaiMemory: memory,
  }
}

export function MeereoProvider({ children }) {
  const [store, setStore] = useState(loadFromStorage)
  const [toasts, setToasts] = useState([])
  const [notifOpen, setNotifOpen] = useState(false)

  // Ref for current store — avoids stale closures in sync() calls
  const storeRef = useRef(store)
  useEffect(() => { storeRef.current = store; window.__MEEREO_STORE__ = store }, [store])

  const justCreated = useRef(false)
  const hydrationDone = useRef(false)

  // ═══ BOOT HYDRATION — PostgreSQL is the source of truth ═══
  // On app load: always verify session via /auth/me (cookie httpOnly),
  // then load all business data from API.
  useEffect(() => {
    if (hydrationDone.current) return
    hydrationDone.current = true

    ;(async () => {
      try {
        // 1. Verify session via cookie — token is refreshed from the response
        const me = await api.auth.me()
        if (!me || !me.id) throw new Error('Invalid session')

        // Restaurer le token en mémoire (utilisé par Bearer pour WS/API)
        if (me.token) setInMemoryToken(me.token)

        const user = {
          id: me.id, email: me.email, name: me.name, type: me.type,
          company: me.company || '', phone: me.phone || '', avatar: me.avatar || '',
          publicId: me.publicId || null,
          slug: me.slug || null,
          wallet: 0,
        }

        // 2. Fetch business data from PostgreSQL (source of truth)
        const [apiAos, apiOffers, apiProjects, apiMarkets, apiMissions, apiDocuments, apiProjectMembers, apiFournisseurs, apiContacts, apiKaiEnt, apiKaiConvs, apiKaiMem, apiPrefs, apiOnboarding, apiActivities, apiRapports, apiNotifications, apiEvents, apiTasks, apiCommandes, apiDecisions, apiTransactions, apiPaymentRequests, apiRegisteredUsers] = await Promise.all([
          api.aos.getAll().catch(() => []),
          api.offers.getAll().catch(() => []),
          api.projects.getAll().catch(() => []),
          api.markets.getAll().catch(() => []),
          api.missions.getAll().catch(() => []),
          api.documents.getAll().catch(() => []),
          api.projectMembers.getAll().catch(() => []),
          api.usersApi.getFournisseurs().catch(() => []),
          api.contacts.getAll().catch(() => []),
          api.kai.getEntitlements().catch(() => []),
          api.kai.getConversations().catch(() => []),
          api.kai.getMemory().catch(() => []),
          api.usersApi.getPrefs().catch(() => ({})),
          api.usersApi.getOnboardingData().catch(() => ({})),
          api.activities.getAll().catch(() => []),
          api.rapports.getAll().catch(() => []),
          api.notifications.getAll().catch(() => []),
          api.events.getAll().catch(() => []),
          api.tasks.getAll().catch(() => []),
          api.commandes.getAll().catch(() => []),
          api.decisions.getAll().catch(() => []),
          api.transactions.getAll().catch(() => []),
          api.paymentRequests.getAll().catch(() => []),
          api.usersApi.getRegistered().catch(() => []),
        ])

        // 3. PostgreSQL is source of truth — replace business data entirely
        // Local-only items (ao_xxx IDs) are discarded; backend data wins
        setStore(prev => {
          const apiClients = apiContacts.filter(c => c.type === 'client')
          const apiIntervenants = apiContacts.filter(c => c.type === 'intervenant')
          const next = {
            ...prev,
            _hydrated: true,
            _checking: false,
            _cachedUser: { id: user.id, type: user.type, name: user.name },
            user,
            users: mergeById([user], Array.isArray(apiRegisteredUsers) ? apiRegisteredUsers : []),
            // Business data: backend replaces local (no merge to avoid ghost duplicates)
            aos: apiAos,
            offers: apiOffers,
            projects: apiProjects,
            markets: apiMarkets,
            missions: apiMissions,
            documents: apiDocuments,
            projectMembers: apiProjectMembers,
            fournisseurs: apiFournisseurs,
            contacts: apiContacts,
            clients: apiClients,
            intervenants: apiIntervenants,
            // KAI — depuis la base
            ...buildKaiState(apiKaiEnt, apiKaiConvs, apiKaiMem),
            // Préférences utilisateur
            clientPrefs: { notifEmail: true, notifPush: true, rappels: false, resume: false, ...(apiPrefs || {}) },
            // Acceptations CGV commission — depuis les préférences en DB
            commissionAcceptances: Array.isArray(apiPrefs?.commissionAcceptances)
              ? apiPrefs.commissionAcceptances
              : (prev.commissionAcceptances || []),
            // Token en mémoire (utilisé pour Bearer/Socket — pas en localStorage)
            _token: me.token || prev._token,
            // Données d'onboarding — BD prioritaire, localStorage en fallback si BD vide
            onboardingData: Object.keys(apiOnboarding || {}).length > 0
              ? apiOnboarding
              : (prev._onboardingByUser?.[user.id] || prev.onboardingData || {}),
            // Activités — depuis la base, avec champ ts mappé depuis createdAt
            activities: Array.isArray(apiActivities)
              ? apiActivities.map(a => ({ ...a, ts: a.ts || a.createdAt }))
              : (prev.activities || []),
            // Rapports — depuis la base
            rapports: Array.isArray(apiRapports) ? apiRapports : (prev.rapports || []),
            // Notes chantier — extraites des rapports pour le suivi projet
            notes: Array.isArray(apiRapports) ? apiRapports.filter(r => r.type === 'note_chantier') : (prev.notes || []),
            // Notifications — depuis la base
            notifications: Array.isArray(apiNotifications) ? apiNotifications : (prev.notifications || []),
            // Événements — depuis la base (remplace les ev_ temporaires)
            events: Array.isArray(apiEvents) ? apiEvents : (prev.events || []),
            // Tâches — depuis la base
            tasks: Array.isArray(apiTasks) ? apiTasks : (prev.tasks || []),
            // Commandes — depuis la base
            commandes: Array.isArray(apiCommandes) ? apiCommandes : (prev.commandes || []),
            // Décisions — depuis la base
            decisions: Array.isArray(apiDecisions) ? apiDecisions : (prev.decisions || []),
            // Transactions — depuis la base
            transactions: Array.isArray(apiTransactions) ? apiTransactions : (prev.transactions || []),
            // Demandes de paiement — depuis la base
            paymentRequests: Array.isArray(apiPaymentRequests) ? apiPaymentRequests : (prev.paymentRequests || []),
          }
          saveToStorage(next)
          return next
        })
        console.log('[MEEREO] Hydration complete — user:', me.email, '— AOs:', apiAos.length, '— projects:', apiProjects.length)
      } catch (e) {
        console.warn('[MEEREO] Session expired or backend down:', e.message)
        // Si l'utilisateur vient de s'inscrire, le cookie peut ne pas encore être
        // reconnu par /auth/me (appelé avant la fin du register). Ne pas effacer
        // la session fraîchement créée.
        if (justCreated.current) {
          setStore(prev => { const next = { ...prev, _hydrated: true, _checking: false }; saveToStorage(next); return next })
          return
        }
        // Cookie invalid / réseau down → vider la session
        setInMemoryToken(null)
        setStore(prev => { const next = { ...prev, _hydrated: true, _checking: false, _cachedUser: null, user: null, _token: null }; saveToStorage(next); return next })
      }
    })()
  }, []) // Run once on mount — no deps needed

  // ═══ SOCKET.IO — connexion automatique dès qu'un token est disponible ═══
  useEffect(() => {
    const token = store._token
    if (!token) {
      disconnectSocket()
      return
    }
    // Initialiser le socket avec le token courant
    const socket = getSocket(token)

    // Écouter les mises à jour de conversation émises par d'autres utilisateurs
    const handleConvUpdated = ({ conversationId, lastMessage }) => {
      setStore(prev => {
        const convs = prev.conversations || []
        const exists = convs.some(c => c.id === conversationId)
        if (!exists) {
          // Nouvelle conversation reçue → re-fetcher la liste complète
          api.conversations.getAll().then(res => {
            const list = Array.isArray(res) ? res : (res?.conversations || [])
            setStore(p => {
              const next = { ...p, conversations: list.length ? list : p.conversations }
              saveToStorage(next)
              return next
            })
          }).catch(() => {})
          return prev
        }
        // Only increment unread and notify when the message is from someone else
        const isOwnMessage = lastMessage?.senderId && prev.user?.id && lastMessage.senderId === prev.user.id
        const next = {
          ...prev,
          conversations: convs.map(c =>
            c.id === conversationId
              ? { ...c, lastMessage, updatedAt: lastMessage?.createdAt || c.updatedAt, unread: isOwnMessage ? (c.unread || 0) : (c.unread || 0) + 1 }
              : c
          ),
          // Do NOT add a local notification here — the server emits notification:new with the correct
          // sender name in the `msg` field. Adding one here would deduplicate (same id: 'msg_<id>')
          // and block the server notification, causing the panel to show blank text.
        }
        saveToStorage(next)
        return next
      })
    }

    socket.on('conversation:updated', handleConvUpdated)

    // Écouter les notifications push (ex: nouvelle offre sur un AO)
    const handleNotifNew = (notif) => {
      // Normalize: some server events send `text` instead of `msg`
      const normalized = notif.msg ? notif : { ...notif, msg: notif.text || '' }
      setStore(prev => {
        const existing = prev.notifications || []
        if (existing.some(n => n.id === normalized.id)) return prev
        const next = { ...prev, notifications: [normalized, ...existing] }
        saveToStorage(next)
        return next
      })
    }
    socket.on('notification:new', handleNotifNew)

    // Écouter les mises à jour projet pour sync temps réel
    const handleProjectUpdated = (data) => {
      if (!data?.projectId) return
      // Refetch projects from API to get the latest state
      api.projects.getAll().then(freshProjects => {
        if (Array.isArray(freshProjects)) {
          setStore(prev => {
            const localOnly = (prev.projects || []).filter(p => String(p.id).startsWith('proj_'))
            const next = { ...prev, projects: [...freshProjects, ...localOnly] }
            saveToStorage(next)
            return next
          })
        }
      }).catch(() => {})
    }
    socket.on('project:updated', handleProjectUpdated)

    // Écouter les nouveaux AO pour mettre à jour la Bourse en temps réel
    const handleAoNew = () => {
      api.aos.getAll().then(freshAos => {
        if (Array.isArray(freshAos)) {
          setStore(prev => {
            const localOnly = (prev.aos || []).filter(a => String(a.id).startsWith('ao_'))
            const next = { ...prev, aos: [...freshAos, ...localOnly] }
            saveToStorage(next)
            return next
          })
        }
      }).catch(() => {})
    }
    socket.on('ao:new', handleAoNew)

    // Charger les conversations depuis l'API à chaque connexion (merge avec locales)
    api.conversations.getAll().then(res => {
      const list = Array.isArray(res) ? res : (res?.conversations || [])
      if (list.length > 0) {
        setStore(prev => {
          // Garder les conversations locales (id commence par conv_) qui n'ont pas d'équivalent backend
          const backendIds = new Set(list.map(c => c.id))
          const localOnly = (prev.conversations || []).filter(c => String(c.id).startsWith('conv_') && !backendIds.has(c.id))
          const next = { ...prev, conversations: [...list, ...localOnly] }
          saveToStorage(next)
          return next
        })
      }
    }).catch(() => {})

    return () => {
      socket.off('conversation:updated', handleConvUpdated)
      socket.off('notification:new', handleNotifNew)
      socket.off('project:updated', handleProjectUpdated)
      socket.off('ao:new', handleAoNew)
      // En dev (React Strict Mode), le cleanup + remount crée 2 sockets simultanés.
      // On déconnecte proprement ici pour éviter "WebSocket closed before established".
      // En prod ce cleanup ne s'exécute qu'au logout ou au changement de token.
      socket.disconnect()
    }
  }, [store._token]) // eslint-disable-line react-hooks/exhaustive-deps

  // ═══ BACKGROUND SYNC — refetch business data every 30s ═══
  // Ensures pro sees AO closed / offer accepted without manual refresh
  useEffect(() => {
    const interval = setInterval(async () => {
      const currentStore = storeRef.current
      if (!currentStore.user) return
      try {
        const [apiAos, apiOffers, apiMarkets, apiMissions, apiProjects, apiDocuments, apiConversations, apiMembers, apiDecisions, apiTasks, apiEvents, apiNotifications, apiContacts, apiRapports, apiTransactions, apiRegisteredUsers] = await Promise.all([
          api.aos.getAll().catch(() => null),
          api.offers.getAll().catch(() => null),
          api.markets.getAll().catch(() => null),
          api.missions.getAll().catch(() => null),
          api.projects.getAll().catch(() => null),
          api.documents.getAll().catch(() => null),
          api.conversations.getAll().catch(() => null),
          api.projectMembers.getAll().catch(() => null),
          api.decisions.getAll().catch(() => null),
          api.tasks.getAll().catch(() => null),
          api.events.getAll().catch(() => null),
          api.notifications.getAll().catch(() => null),
          api.contacts.getAll().catch(() => null),
          api.rapports.getAll().catch(() => null),
          api.transactions.getAll().catch(() => null),
          api.usersApi.getRegistered().catch(() => null),
        ])
        if (!apiAos) return // Backend unreachable, skip
        if (!storeRef.current.user) return // User logged out during fetch
        setStore(prev => {
          if (!prev.user) return prev // Double-check: don't overwrite after logout
          // Merge conversations: keep local ones not yet synced, add backend ones
          let mergedConvs = prev.conversations || []
          const convList = Array.isArray(apiConversations) ? apiConversations : (apiConversations?.conversations || null)
          if (convList) {
            const backendIds = new Set(convList.map(c => c.id))
            const localOnly = mergedConvs.filter(c => !backendIds.has(c.id) && String(c.id).startsWith('conv_'))
            mergedConvs = [...convList, ...localOnly]
          }
          // Merge projects: keep local-only proj_ entries pending backend sync
          let mergedProjects = prev.projects || []
          if (apiProjects) {
            const backendProjIds = new Set(apiProjects.map(p => p.id))
            const localOnlyProjects = mergedProjects.filter(p => !backendProjIds.has(p.id) && String(p.id).startsWith('proj_'))
            mergedProjects = [...apiProjects, ...localOnlyProjects]
          }
          // Merge markets: keep local-only mkt_ entries pending backend sync
          let mergedMarkets = prev.markets || []
          if (apiMarkets) {
            const backendMktIds = new Set(apiMarkets.map(m => m.id))
            const localOnlyMarkets = mergedMarkets.filter(m => !backendMktIds.has(m.id) && String(m.id).startsWith('mkt_'))
            mergedMarkets = [...apiMarkets, ...localOnlyMarkets]
          }
          // Merge AOs: keep local-only ao_ entries pending backend sync
          let mergedAOs = prev.aos || []
          const backendAoIds = new Set(apiAos.map(a => a.id))
          const localOnlyAOs = mergedAOs.filter(a => !backendAoIds.has(a.id) && String(a.id).startsWith('ao_'))
          mergedAOs = [...apiAos, ...localOnlyAOs]
          // Merge missions: keep local-only msn_ entries pending backend sync
          let mergedMissions = prev.missions || []
          if (apiMissions) {
            const backendMsnIds = new Set(apiMissions.map(m => m.id))
            const localOnlyMissions = mergedMissions.filter(m => !backendMsnIds.has(m.id) && String(m.id).startsWith('msn_'))
            mergedMissions = [...apiMissions, ...localOnlyMissions]
          }
          const next = {
            ...prev,
            aos: mergedAOs,
            offers: apiOffers || prev.offers,
            markets: mergedMarkets,
            missions: mergedMissions,
            projects: mergedProjects,
            documents: apiDocuments || prev.documents,
            projectMembers: apiMembers || prev.projectMembers,
            conversations: mergedConvs,
            decisions: apiDecisions || prev.decisions,
            tasks: apiTasks || prev.tasks,
            events: apiEvents || prev.events,
            notifications: (() => {
              if (!apiNotifications) return prev.notifications
              // Merge: keep real-time notifications received via WebSocket that backend hasn't indexed yet
              const backendIds = new Set(apiNotifications.map(n => n.id))
              const localOnly = (prev.notifications || []).filter(n => !backendIds.has(n.id))
              return [...apiNotifications, ...localOnly]
            })(),
            contacts: apiContacts || prev.contacts,
            rapports: apiRapports || prev.rapports,
            notes: apiRapports ? apiRapports.filter(r => r.type === 'note_chantier') : (prev.notes || []),
            transactions: apiTransactions || prev.transactions,
            users: apiRegisteredUsers ? mergeById([prev.user].filter(Boolean), apiRegisteredUsers) : prev.users,
          }
          saveToStorage(next)
          return next
        })

        // ── Sync local-only AOs (created while server was down) ──────────────
        // IDs starting with 'ao_' were generated offline; push them to the backend now.
        const localAOs = (storeRef.current.aos || []).filter(a => String(a.id).startsWith('ao_'))
        for (const localAO of localAOs) {
          try {
            const backendAO = await api.aos.create({
              title: localAO.title,
              description: localAO.description || '',
              budget: localAO.budget || '',
              lot: localAO.lot || '',
              requestedTrade: localAO.requestedTrade || '',
              visibilityScope: localAO.visibilityScope || 'public',
              projectId: localAO.projectId || null,
              createdByClient: localAO.createdByClient || false,
              autoGenerated: localAO.autoGenerated || false,
            })
            // Replace temp ID with real backend ID
            setStore(prev => {
              const next = {
                ...prev,
                aos: prev.aos.map(a =>
                  a.id === localAO.id
                    ? { ...a, id: backendAO.id, status: backendAO.status || a.status, createdAt: backendAO.createdAt || a.createdAt }
                    : a
                ),
              }
              saveToStorage(next)
              return next
            })
          } catch (_) { /* server rejected or still down — retry next tick */ }
        }
      } catch { /* silent */ }
    }, 30000)
    return () => clearInterval(interval)
  }, [])

  const updateStore = useCallback((updater) => {
    setStore(prev => {
      const next = typeof updater === 'function' ? updater(prev) : { ...prev, ...updater }
      saveToStorage(next)
      return next
    })
  }, [])

  const _toastCounter = useRef(0)
  const showToast = useCallback((msg, color) => {
    const id = ++_toastCounter.current
    setToasts(prev => [...prev, { id, msg, color: color || 'info' }])
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id))
    }, 3200)
  }, [])

  const log = useCallback((action, data) => {
    updateStore(prev => {
      const activities = [
        {
          id: Date.now(), action, data: data || null,
          userId: prev.user?.id || null,
          userType: prev.user?.type || null,
          userName: prev.user?.name || null,
          ts: new Date().toISOString(),
        },
        ...prev.activities
      ].slice(0, 200)
      return { ...prev, activities }
    })
    sync(api.activities.create({ action, data: data || null, userId: storeRef.current.user?.id || null }))
  }, [updateStore])

  const addNotif = useCallback((msg, type, link, page) => {
    updateStore(prev => {
      const role = prev.user?.type || null
      const notifications = [
        { id: Date.now(), msg, type: type || 'info', link: link || null, page: page || null, read: false, ts: new Date().toISOString(), role },
        ...prev.notifications
      ].slice(0, 50)
      return { ...prev, notifications }
    })
    sync(api.notifications.create({ msg, type: type || 'info', role: storeRef.current.user?.type || null, userId: storeRef.current.user?.id || null }))
  }, [updateStore])

  const markNotifRead = useCallback((notifId) => {
    updateStore(prev => ({
      ...prev,
      notifications: (prev.notifications || []).map(n => n.id === notifId ? { ...n, read: true } : n)
    }))
    // Persister en DB
    api.notifications.markRead(notifId).catch(() => {})
  }, [updateStore])

  const markNotifsRead = useCallback(() => {
    updateStore(prev => {
      const role = prev.user?.type
      return {
        ...prev,
        notifications: (prev.notifications || []).map(n => (!n.role || n.role === role) ? { ...n, read: true } : n)
      }
    })
    // Persister en DB
    api.notifications.markAllRead().catch(() => {})
  }, [updateStore])

  // ═══ REGISTER — Creates account on backend, keeps user logged in and redirects.
  const createUser = useCallback(async (data) => {
    justCreated.current = true // Skip boot hydration for fresh accounts
    const user = {
      id: 'u_' + Date.now(),
      type: data.type || 'pro',
      name: data.name || data.nom || '',
      company: data.company || data.entreprise || data.societe || '',
      email: data.email || '',
      phone: data.phone || data.tel || '',
      avatar: data.avatar || '',
      wallet: 0,
      createdAt: new Date().toISOString()
    }
    // Build onboardingData — keep only serializable, reasonably-sized fields
    const obData = {}
    const textKeys = ['userType','prenom','nom','civilite','entreprise','metier','ville','annee','rccm','ncc',
      'email','emailPro','tel','telPro','slogan','bio','projetsN','effectif','pays',
      'situation','projectType','location','surface','budget','description','architecteEmail',
      'delaiLivraison','logoColor','logoShape','logoTypo','bannerPosition','emailVerified']
    textKeys.forEach(k => { if (data[k] !== undefined && data[k] !== null) obData[k] = data[k] })
    if (Array.isArray(data.secteurs)) obData.secteurs = data.secteurs
    if (Array.isArray(data.services)) obData.services = data.services
    if (Array.isArray(data.zones)) obData.zones = data.zones
    if (Array.isArray(data.categories)) obData.categories = data.categories
    const safeImg = (v) => {
      if (!v || typeof v !== 'string') return ''
      if (!v.startsWith('data:')) return v
      if (v.length < 2500000) return v
      console.warn('[MEEREO] Image trop volumineuse (' + Math.round(v.length / 1024) + 'Ko)')
      return v.length < 5000000 ? v : ''
    }
    obData.photoUrl = safeImg(data.photoUrl)
    obData.logoFileUrl = safeImg(data.logoFileUrl)
    obData.coverUrl = safeImg(data.coverUrl)
    obData.bannerUrl = safeImg(data.bannerUrl)
    if (data.team) obData.cockpitTeam = data.team.map(m => ({ nom: m.nom || m.name || '', role: m.role || '', photoUrl: safeImg(m.photoUrl) }))
    // Portfolio — keep small images
    if (data.portfolio) obData.portfolio = data.portfolio.map(p => ({ img: safeImg(p.img), cap: p.cap || '', feat: p.feat || false })).filter(p => p.img)
    else if (data.portfolioFiles) obData.portfolio = (data.portfolioFiles || []).filter(u => typeof u === 'string').map((url, i) => ({ img: safeImg(url), cap: 'Réalisation ' + (i+1), feat: i === 0 })).filter(p => p.img)
    if (data.products) obData.products = data.products.map(p => ({ name: p.name, price: p.price, unit: p.unit, category: p.category, photoUrl: safeImg(p.photoUrl) }))

    updateStore(prev => {
      const exists = prev.users.find(u => u && u.email === user.email)
      const savedObs = { ...(prev._onboardingByUser || {}) }
      if (prev.user?.id && prev.onboardingData) {
        savedObs[prev.user.id] = prev.onboardingData
      }
      return {
        ...prev,
        user,
        users: exists ? prev.users : [...prev.users, user],
        onboardingData: obData,
        _onboardingByUser: savedObs,
        ...buildKaiState([], [], []),
        notifications: [],
        activities: [],
        messages: [],
        conversations: [],
      }
    })

    // Register on backend to get a JWT token
    const userPassword = data.password || user.id
    const safeImgUrl = (v) => (v && typeof v === 'string' && !v.startsWith('data:')) ? v : undefined
    try {
      const res = await api.auth.register({
        email: user.email || 'user_' + user.id + '@meereo.ci',
        password: userPassword,
        name: user.name,
        type: user.type,
        ...(user.company    ? { company: user.company }    : {}),
        ...(user.phone      ? { phone: user.phone }        : {}),
        ...(data.ville      ? { ville: data.ville }        : {}),
        ...(data.pays       ? { pays: data.pays }          : {}),
        ...(data.metier     ? { metier: data.metier }      : obData.secteurs?.[0] ? { metier: obData.secteurs[0] } : {}),
        ...(obData.entreprise ? { entreprise: obData.entreprise } : {}),
        ...(obData.rccm       ? { rccm: obData.rccm }             : {}),
        ...(obData.ncc        ? { ncc: obData.ncc }               : {}),
        ...(obData.annee      ? { annee: obData.annee }           : {}),
        ...(obData.slogan     ? { slogan: obData.slogan }         : {}),
        ...(obData.bio        ? { bio: obData.bio }               : {}),
        ...(obData.projetsN   ? { projetsN: obData.projetsN }     : {}),
        ...(obData.effectif   ? { effectif: obData.effectif }     : {}),
        ...(obData.tel || obData.telPro ? { tel: obData.tel || obData.telPro } : {}),
        ...(obData.logoColor  ? { logoColor: obData.logoColor }   : {}),
        ...(obData.logoShape  ? { logoShape: obData.logoShape }   : {}),
        ...(obData.logoTypo   ? { logoTypo: obData.logoTypo }     : {}),
        ...(obData.secteurs?.length   ? { secteurs: obData.secteurs }   : {}),
        ...(obData.services?.length   ? { services: obData.services }   : {}),
        ...(obData.zones?.length      ? { zones: obData.zones }         : {}),
        ...(obData.categories?.length ? { categories: obData.categories } : {}),
        ...(safeImgUrl(obData.logoFileUrl)  ? { logoFileUrl: obData.logoFileUrl }   : {}),
        ...(safeImgUrl(obData.photoUrl)     ? { photoUrl: obData.photoUrl }         : {}),
        ...(safeImgUrl(obData.coverUrl)     ? { coverUrl: obData.coverUrl }         : {}),
      })
      if (res?.token) {
        // Store token + hydrate shared business data from PostgreSQL
        const [apiAos, apiOffers, apiProjects, apiMarkets] = await Promise.all([
          api.aos.getAll().catch(() => []),
          api.offers.getAll().catch(() => []),
          api.projects.getAll().catch(() => []),
          api.markets.getAll().catch(() => []),
        ])
        const realUser = {
          ...user,
          ...res.user,
          id: res.user?.id || user.id,
          name: res.user?.name || user.name,
          type: res.user?.type || user.type,
          company: res.user?.company || user.company,
          publicId: res.user?.publicId || null,
          slug: res.user?.slug || null,
        }
        setInMemoryToken(res.token)
        storeRef.current = { ...storeRef.current, user: realUser, _token: res.token }
        updateStore(prev => {
          const updatedObs = { ...(prev._onboardingByUser || {}) }
          if (res.user?.id && user.id !== res.user.id) {
            if (prev.onboardingData) updatedObs[res.user.id] = prev.onboardingData
            delete updatedObs[user.id]
          }
          return {
            ...prev,
            user: realUser,
            users: mergeById(prev.users || [], [realUser]),
            _onboardingByUser: updatedObs,
            _token: res.token,
            _hydrated: true,
            aos: apiAos,
            offers: apiOffers,
            projects: apiProjects,
            markets: apiMarkets,
          }
        })
        // Persister onboardingData en BD
        if (obData && Object.keys(obData).length > 0) {
          if (obData.coverUrl && !obData.bannerUrl) obData.bannerUrl = obData.coverUrl
          api.usersApi.updateOnboardingData(obData).catch(() => {})
        }
      }
    } catch (e) {
      // Register failed — check if RCCM duplicate (don't fallback to login)
      if (e.message?.includes('RCCM')) {
        updateStore(prev => ({ ...prev, user: null, users: (prev.users || []).filter(u => u.id !== user.id), onboardingData: null }))
        throw new Error('Ce numéro RCCM est déjà utilisé par une autre entreprise')
      }
      // 409 = email exists → try login instead
      console.warn('[MEEREO] Register failed:', e.message, '— trying login')
      try {
        const loginRes = await api.auth.login({ email: user.email, password: userPassword })
        if (loginRes?.token) {
          const realUser = {
            ...user,
            ...loginRes.user,
            id: loginRes.user.id,
            name: loginRes.user.name || user.name,
            type: loginRes.user.type || user.type,
            company: loginRes.user.company || user.company,
            publicId: loginRes.user.publicId || null,
            slug: loginRes.user.slug || null,
          }
          const [apiAos, apiOffers, apiProjects, apiMarkets] = await Promise.all([
            api.aos.getAll().catch(() => []),
            api.offers.getAll().catch(() => []),
            api.projects.getAll().catch(() => []),
            api.markets.getAll().catch(() => []),
          ])
          setInMemoryToken(loginRes.token)
          storeRef.current = { ...storeRef.current, user: realUser, _token: loginRes.token }
          updateStore(prev => {
            const updatedObs = { ...(prev._onboardingByUser || {}) }
            if (loginRes.user?.id && user.id !== loginRes.user.id) {
              if (prev.onboardingData) updatedObs[loginRes.user.id] = prev.onboardingData
              delete updatedObs[user.id]
            }
            return {
              ...prev,
              user: realUser,
              users: mergeById(prev.users || [], [realUser]),
              _onboardingByUser: updatedObs,
              _token: loginRes.token,
              _hydrated: true,
              aos: apiAos,
              offers: apiOffers,
              projects: apiProjects,
              markets: apiMarkets,
            }
          })
        }
      } catch (loginErr) {
        // Both register and login failed — clean up and throw
        if (loginErr?.response?.status === 401) {
          updateStore(prev => ({
            ...prev,
            user: null,
            users: (prev.users || []).filter(u => u.id !== user.id),
            onboardingData: null,
          }))
          throw new Error('Un compte existe déjà avec cet email. Connectez-vous ou réinitialisez votre mot de passe.')
        }
        console.warn('[MEEREO] Login fallback also failed:', loginErr.message)
      }
    }
    log('USER_CREATED', { name: user.name, type: user.type })
    addNotif('Bienvenue sur MEEREO, ' + (user.name || user.company) + '\u00a0!', 'green', null, 'dashboard')
    return user
  }, [updateStore, log, addNotif])

  // ═══ LOGIN — API-first, PostgreSQL is source of truth ═══
  // Returns: { user object } on success, or throws Error with user-facing message
  const loginUser = useCallback(async (email, password) => {
    // 1. API-first: always try backend authentication
    try {
      const res = await api.auth.login({ email, password })
      if (res?.user && res?.token) {
        const backendUser = {
          id: res.user.id,
          type: res.user.type || 'pro',
          name: res.user.name || '',
          company: res.user.company || '',
          email: res.user.email || email,
          phone: res.user.phone || '',
          avatar: res.user.avatar || '',
          publicId: res.user.publicId || null,
          slug: res.user.slug || null,
          wallet: 0,
        }
        // 2. Hydrate business data from PostgreSQL
        const [apiAos, apiOffers, apiProjects, apiMarkets, apiMissions, apiProjectMembers, apiFournisseurs, apiContacts, apiKaiEnt, apiKaiConvs, apiKaiMem, apiPrefs, apiOnboarding] = await Promise.all([
          api.aos.getAll().catch(() => []),
          api.offers.getAll().catch(() => []),
          api.projects.getAll().catch(() => []),
          api.markets.getAll().catch(() => []),
          api.missions.getAll().catch(() => []),
          api.projectMembers.getAll().catch(() => []),
          api.usersApi.getFournisseurs().catch(() => []),
          api.contacts.getAll().catch(() => []),
          api.kai.getEntitlements().catch(() => []),
          api.kai.getConversations().catch(() => []),
          api.kai.getMemory().catch(() => []),
          api.usersApi.getPrefs().catch(() => ({})),
          api.usersApi.getOnboardingData().catch(() => ({})),
        ])
        // 3. Update store with API data + token + restore per-user onboardingData
        updateStore(prev => {
          // Save current user's onboardingData before switching
          const savedObs = { ...(prev._onboardingByUser || {}) }
          if (prev.user?.id && prev.onboardingData) {
            savedObs[prev.user.id] = prev.onboardingData
          }
          // Restore onboardingData for the logging-in user ONLY — never inherit another user's data
          // Also search by email as fallback for sessions with old temp-keyed OB data
          const restoredOb = savedObs[backendUser.id]
            || Object.values(savedObs).find(ob => ob && (ob.email === backendUser.email || ob.emailPro === backendUser.email))
            || null
          // If found by email, migrate the key to the real backend ID
          if (!savedObs[backendUser.id] && restoredOb) {
            savedObs[backendUser.id] = restoredOb
            // Remove old temp-keyed entry
            for (const k of Object.keys(savedObs)) {
              if (k !== backendUser.id && savedObs[k] === restoredOb) delete savedObs[k]
            }
          }
          return {
            ...prev,
            user: backendUser,
            users: mergeById(prev.users || [], [backendUser]),
            _token: res.token,
            _hydrated: true,
            _cachedUser: { id: backendUser.id, type: backendUser.type, name: backendUser.name },
            _onboardingByUser: savedObs,
            onboardingData: restoredOb,
            // Business data: backend replaces local (source of truth)
            aos: apiAos,
            offers: apiOffers,
            projects: apiProjects,
            markets: apiMarkets,
            missions: apiMissions,
            projectMembers: apiProjectMembers,
            fournisseurs: apiFournisseurs,
            contacts: apiContacts,
            clients: apiContacts.filter(c => c.type === 'client'),
            intervenants: apiContacts.filter(c => c.type === 'intervenant'),
            // KAI — depuis la base
            ...buildKaiState(apiKaiEnt, apiKaiConvs, apiKaiMem),
            // Préférences utilisateur
            clientPrefs: { notifEmail: true, notifPush: true, rappels: false, resume: false, ...(apiPrefs || {}) },
            // Données d'onboarding — BD prioritaire, localStorage en fallback si BD vide
            onboardingData: Object.keys(apiOnboarding || {}).length > 0
              ? apiOnboarding
              : (prev._onboardingByUser?.[backendUser.id] || prev.onboardingData || {}),
          }
        })
        log('USER_LOGIN', { email, source: 'api' })
        return backendUser
      }
    } catch (e) {
      const msg = e.message || ''
      const status = e.status || 0

      // Compte supprimé — erreur définitive, ne pas chercher en local
      if (msg.includes('supprimé')) throw new Error('Ce compte a été supprimé')

      // 401 depuis le backend : email introuvable OU mauvais mot de passe
      // On distingue grâce au compte local :
      //   • Pas de compte local → email inconnu → "Aucun compte trouvé" (return null)
      //   • Compte local trouvé → il a été créé offline, on le migre vers PostgreSQL
      if (status === 401 || msg.includes('Mot de passe incorrect') || msg.includes('Email ou mot de passe')) {
        let localUser = null
        updateStore(prev => {
          localUser = (prev.users || []).find(
            u => u && (u.email || '').toLowerCase() === email.toLowerCase() && u.email !== ''
          ) || null
          return prev
        })

        if (!localUser) {
          // L'email n'existe vraiment nulle part → message clair
          return null
        }

        // Compte trouvé en local mais pas encore dans PostgreSQL
        // Tentative de migration : on l'enregistre côté backend avec le mot de passe fourni
        console.info('[LOGIN] Compte local détecté — migration vers PostgreSQL…')
        try {
          const ob = (() => {
            let d = null
            updateStore(prev => {
              d = prev._onboardingByUser?.[localUser.id] || prev.onboardingData || null
              return prev
            })
            return d
          })()

          const migrateRes = await api.auth.register({
            email: localUser.email,
            password,
            name: localUser.name || localUser.company || 'Utilisateur',
            type: localUser.type || 'pro',
            company: localUser.company || null,
            phone: localUser.phone || ob?.tel || null,
            metier: ob?.metier || ob?.secteurs?.[0] || null,
            ville: localUser.ville || ob?.ville || null,
            // Profil complet selon le type
            ...(ob || {}),
          })

          if (migrateRes?.user && migrateRes?.token) {
            // Migration réussie — mettre à jour le store avec le vrai ID backend
            const migratedUser = {
              id: migrateRes.user.id,
              type: migrateRes.user.type || localUser.type,
              name: migrateRes.user.name || localUser.name,
              company: migrateRes.user.company || localUser.company || '',
              email: migrateRes.user.email,
              phone: migrateRes.user.phone || localUser.phone || '',
              avatar: migrateRes.user.avatar || localUser.avatar || '',
              wallet: 0,
            }
            updateStore(prev => {
              const savedObs = { ...(prev._onboardingByUser || {}) }
              const ob = prev.onboardingData || savedObs[localUser.id] || null
              if (ob) savedObs[migratedUser.id] = ob
              delete savedObs[localUser.id]
              return {
                ...prev,
                user: migratedUser,
                users: mergeById(prev.users || [], [migratedUser]),
                _token: migrateRes.token,
                _hydrated: true,
                _onboardingByUser: savedObs,
                onboardingData: ob,
              }
            })
            log('USER_LOGIN', { email, source: 'migrated' })
            return migratedUser
          }
        } catch (regErr) {
          // 409 = email déjà en base avec un autre mot de passe → mauvais mot de passe
          if (regErr.status === 409) {
            throw new Error('Mot de passe incorrect')
          }
          // Autre erreur de migration — laisser passer au fallback local
          console.warn('[LOGIN] Migration échouée :', regErr.message)
        }

        // Fallback ultime : connecter avec le compte local (mode dégradé / offline)
        updateStore(prev => {
          const savedObs = { ...(prev._onboardingByUser || {}) }
          if (prev.user?.id && prev.onboardingData) savedObs[prev.user.id] = prev.onboardingData
          return { ...prev, user: localUser, onboardingData: savedObs[localUser.id] || null, _onboardingByUser: savedObs }
        })
        log('USER_LOGIN', { email, source: 'local_fallback' })
        return localUser
      }

      // Erreur réseau (serveur inaccessible) — fallback local
      console.warn('[LOGIN] Backend inaccessible, fallback local :', msg)
    }

    // 4. Fallback réseau : chercher en local si le serveur est down
    let found = null
    updateStore(prev => {
      found = (prev.users || []).find(
        u => u && (u.email || '').toLowerCase() === email.toLowerCase() && u.status !== 'deleted' && u.email !== ''
      ) || null
      if (found) {
        const savedObs = { ...(prev._onboardingByUser || {}) }
        if (prev.user?.id && prev.onboardingData) savedObs[prev.user.id] = prev.onboardingData
        return { ...prev, user: found, onboardingData: savedObs[found.id] || null, _onboardingByUser: savedObs }
      }
      return prev
    })
    if (found) {
      log('USER_LOGIN', { email, source: 'local' })
      return found
    }
    // 5. Introuvable partout
    return null
  }, [updateStore, log])

  // ── Organisation ──
  const createOrganization = useCallback((data) => {
    const org = {
      id: 'org_' + Date.now(),
      name: data.name || data.nom || '',
      type: data.type || 'entreprise', // entreprise, cabinet, bet, bureau_controle
      adminId: store.user?.id || null,
      members: [{ userId: store.user?.id, role: 'admin', joinedAt: new Date().toISOString() }],
      logo: data.logo || null,
      rccm: data.rccm || '',
      email: data.email || '',
      tel: data.tel || '',
      ville: data.ville || '',
      pays: data.pays || 'CI',
      createdAt: new Date().toISOString(),
    }
    updateStore(prev => ({ ...prev, organizations: [...(prev.organizations || []), org] }))
    return org
  }, [store.user, updateStore])

  const addMemberToOrg = useCallback((orgId, memberData) => {
    updateStore(prev => ({
      ...prev,
      organizations: (prev.organizations || []).map(o => o.id === orgId ? {
        ...o,
        members: [...o.members, { userId: memberData.userId || null, email: memberData.email, role: memberData.role || 'member', joinedAt: new Date().toISOString() }]
      } : o)
    }))
  }, [updateStore])

  // ═══ PROJECT MEMBERSHIP (multi-acteurs) — déclaré avant createProject ═══

  const addProjectMember = useCallback((projectId, userId, role, meta = {}) => {
    updateStore(prev => {
      const exists = (prev.projectMembers || []).some(m => m.projectId === projectId && m.userId === userId)
      if (exists) return prev
      const membership = {
        id: 'pm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        projectId,
        userId,
        role: role || ROLES.PRO_MEMBER,
        userName: meta.userName || '',
        userEmail: meta.userEmail || '',
        organizationId: meta.organizationId || null,
        joinedAt: new Date().toISOString(),
      }
      return { ...prev, projectMembers: [...(prev.projectMembers || []), membership] }
    })
    sync(api.projectMembers.create({ projectId, userId, role: role || ROLES.PRO_MEMBER, userName: meta.userName || '', userEmail: meta.userEmail || '' }))
    log('PROJECT_MEMBER_ADDED', { projectId, userId, role })
    // Ajouter le nouveau membre au groupe de discussion du projet (si existant)
    const memberName = meta.userName || userId
    if (memberName) {
      updateStore(prev => ({
        ...prev,
        conversations: (prev.conversations || []).map(c => {
          if (c.projectId === projectId && c.isGroup && !c.participants?.includes(memberName)) {
            return { ...c, participants: [...(c.participants || []), memberName], dernier: memberName + ' a rejoint le groupe', time: 'Maintenant' }
          }
          return c
        }),
      }))
    }
  }, [updateStore, log])

  const removeProjectMember = useCallback((projectId, userId) => {
    updateStore(prev => ({
      ...prev,
      projectMembers: (prev.projectMembers || []).filter(m => !(m.projectId === projectId && m.userId === userId)),
    }))
    log('PROJECT_MEMBER_REMOVED', { projectId, userId })
  }, [updateStore, log])

  const getProjectMembers = useCallback((projectId) => {
    return (store.projectMembers || []).filter(m => m.projectId === projectId)
  }, [store.projectMembers])

  const createProject = useCallback((data) => {
    // Use storeRef for fresh values — avoids stale closure after createUser (same pattern as createAO)
    const currentUser = storeRef.current.user
    const p = {
      id: data.id || 'proj_' + Date.now(),
      color: data.color || autoProjectColor(storeRef.current.projects || []),
      name: data.name || data.nom || 'Nouveau projet',
      // clientId must come from data — never fall back to currentUser.id (that's ownerId)
      clientId: data.clientId || null,
      clientEmail: data.clientEmail || null,
      clientInviteStatus: data.clientEmail ? 'pending' : null,
      ownerId: data.ownerId || currentUser?.id || null,
      nom: data.name || data.nom || 'Nouveau projet',
      type: data.type || '',
      budget: data.budget || '',
      status: 'draft',
      phase: data.phase || 'ESQUISSE',
      progress: 0,
      avancement: data.avancement || 0,
      team: data.team || [],
      address: data.address || '',
      localisation: data.address || '',
      client: data.client || '',
      livraison: data.livraison || '',
      priorite: data.priorite || 'Normale',
      description: data.description || '',
      etapes: [],
      createdAt: new Date().toISOString()
    }
    updateStore(prev => {
      const updates = { ...prev, projects: [...prev.projects, p] }
      // Propager date livraison vers agenda
      if (p.livraison) {
        const evt = {
          id: 'evt_liv_' + p.id,
          title: 'Livraison — ' + p.nom,
          date: p.livraison,
          type: 'deadline',
          projectId: p.id,
          color: '#FF9500',
          auto: true,
        }
        updates.events = [...(prev.events || []), evt]
      }
      return updates
    })
    // Sync to PostgreSQL — then replace local proj_ ID with the real backend UUID
    const localId = p.id
    const creatorRole = currentUser?.type === 'client' ? ROLES.CLIENT : ROLES.PRO_ADMIN
    api.projects.create({ nom: p.nom, type: p.type, phase: p.phase, budget: p.budget, adresse: p.address || p.localisation, livraison: p.livraison, priorite: p.priorite, description: p.description, avancement: p.avancement, status: p.status, client: p.client, clientEmail: p.clientEmail, clientId: p.clientId || null, sourceAoId: p.sourceAoId || null, etapes: p.etapes || null, equipe: p.team || p.equipe || null, color: p.color || null })
      .then(created => {
        if (!created?.id) return
        const realId = created.id
        if (realId === localId) return
        // Swap local proj_ ID → real backend UUID in projects, members, conversations, events
        updateStore(prev => ({
          ...prev,
          projects: (prev.projects || []).map(pr => pr.id === localId ? { ...pr, id: realId } : pr),
          projectMembers: (prev.projectMembers || []).map(m => m.projectId === localId ? { ...m, projectId: realId } : m),
          conversations: (prev.conversations || []).map(c => c.projectId === localId ? { ...c, id: c.id.includes(localId) ? c.id.replace(localId, realId) : c.id, projectId: realId } : c),
          events: (prev.events || []).map(e => e.projectId === localId ? { ...e, id: e.id?.includes(localId) ? e.id.replace(localId, realId) : e.id, projectId: realId } : e),
        }))
        // Now register the creator as a member with the real project ID
        sync(api.projectMembers.create({ projectId: realId, userId: currentUser?.id, role: creatorRole, userName: currentUser?.name || '', userEmail: currentUser?.email || '' }))
        // Sync livraison event with real project ID
        if (p.livraison) sync(api.events.create({ titre: 'Livraison — ' + p.nom, date: p.livraison, type: 'Livraison projet', projectId: realId, color: '#7C3AED' }))
      })
      .catch(e => console.warn('[createProject] backend sync failed:', e.message))
    log('PROJECT_CREATED', { name: p.name })
    emitEvent('project_created', { projectName: p.name }, { notifMsg: 'Projet \u00ab ' + p.name + ' \u00bb cr\u00e9\u00e9', notifType: 'green' })
    showToast('\u2705 Projet \u00ab ' + p.name + ' \u00bb cr\u00e9\u00e9', 'green')
    // Local-only member record (so project appears immediately in getUserProjects via memberProjectIds)
    // Will be replaced by the real backend member record once api.projects.create resolves
    addProjectMember(p.id, currentUser?.id, creatorRole, { userName: currentUser?.name, userEmail: currentUser?.email })
    // Créer automatiquement le groupe de discussion du projet
    const groupConvId = 'conv_grp_' + p.id
    const groupConv = {
      id: groupConvId,
      nom: p.name,
      type: 'equipe',
      avatar: (p.name || '?')[0].toUpperCase(),
      color: p.color || '#191c1d',
      isGroup: true,
      projectId: p.id,
      participants: [currentUser?.name || 'Vous'],
      invited: false,
      dernier: 'Groupe créé',
      time: 'Maintenant',
      unread: 0,
      msgs: [],
    }
    updateStore(prev => ({
      ...prev,
      conversations: [groupConv, ...(prev.conversations || []).filter(c => c.id !== groupConvId)],
    }))
    // Auto-invite si email client fourni
    if (data.clientEmail) {
      addNotif('Invitation envoyée à ' + data.clientEmail + ' pour le projet « ' + p.name + ' »', 'blue', null, 'projets')
    }
    // Parcours 1 : auto-créer un AO pour Bureau d'Architecture si mode recherche
    if (data.accompagnement === 'recherche' || data.searchArchitect) {
      const aoData = {
        title: "Recherche Bureau d'Architecture — " + p.name,
        description: p.description || '',
        budget: p.budget || '',
        lot: "Bureau d'Architecture",
        requestedTrade: "Bureau d'Architecture",
        visibilityScope: 'public',
        projectId: p.id,
        createdByClient: true,
        autoGenerated: true,
      }
      const tempAoId = 'ao_auto_' + Date.now()
      updateStore(prev => ({ ...prev, aos: [...(prev.aos || []), { ...aoData, id: tempAoId, status: 'open', ownerUserId: currentUser?.id, createdAt: new Date().toISOString() }] }))
      api.aos.create(aoData).then(created => {
        if (created?.id) updateStore(prev => ({ ...prev, aos: (prev.aos || []).map(a => a.id === tempAoId ? { ...a, ...created } : a) }))
      }).catch(() => {})
      addNotif("Appel d'offres publié automatiquement pour trouver un architecte", 'blue', null, 'bourse')
    }
    return p
  }, [store.user, updateStore, log, addNotif, showToast, addProjectMember])

  const deleteProject = useCallback((projectId) => {
    // Soft-delete : le projet passe en 'stopped' — toujours visible pour le client
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).map(p =>
        p.id === projectId ? { ...p, status: 'stopped', stoppedAt: new Date().toISOString() } : p
      ),
      taskStates: (() => { const ts = { ...(prev.taskStates || {}) }; delete ts[projectId]; return ts })()
    }))
    sync(api.projects.update(projectId, { status: 'stopped' }))
    log('PROJECT_STOPPED', { projectId })
    addNotif('Projet arrêté', 'orange', null, 'projets')
    showToast('Projet arrêté', 'orange')
  }, [updateStore, log, addNotif, showToast])

  const hardDeleteProject = useCallback((projectId) => {
    // Hard delete : suppression définitive (uniquement depuis les archives)
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).filter(p => p.id !== projectId),
      taskStates: (() => { const ts = { ...(prev.taskStates || {}) }; Object.keys(ts).forEach(k => { if (k.startsWith(projectId + '_')) delete ts[k] }); return ts })()
    }))
    sync(api.projects.delete(projectId))
    log('PROJECT_DELETED', { projectId })
    addNotif('Projet supprimé', 'info', null, 'projets')
    showToast('Projet supprimé')
  }, [updateStore, log, addNotif, showToast])

  const stopProject = useCallback((projectId) => {
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).map(p =>
        p.id === projectId ? { ...p, status: 'stopped', stoppedAt: new Date().toISOString() } : p
      ),
    }))
    sync(api.projects.update(projectId, { status: 'stopped' }))
    log('PROJECT_STOPPED', { projectId })
    addNotif('Projet arrêté', 'orange', null, 'projets')
    showToast('Projet arrêté', 'orange')
  }, [updateStore, log, addNotif, showToast])

  const archiveProject = useCallback((projectId) => {
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).map(p =>
        p.id === projectId ? { ...p, status: 'archived', archivedAt: new Date().toISOString() } : p
      ),
    }))
    sync(api.projects.update(projectId, { status: 'archived' }))
    log('PROJECT_ARCHIVED', { projectId })
    addNotif('Projet archivé', 'info', null, 'projets')
    showToast('Projet archivé', 'info')
  }, [updateStore, log, addNotif, showToast])

  const unarchiveProject = useCallback((projectId) => {
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).map(p =>
        p.id === projectId ? { ...p, status: 'active', archivedAt: null } : p
      ),
    }))
    sync(api.projects.update(projectId, { status: 'active' }))
    log('PROJECT_UNARCHIVED', { projectId })
    showToast('Projet restauré', 'green')
  }, [updateStore, log, showToast])

  const updateProject = useCallback((projectId, updates) => {
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).map(p => {
        if (p.id !== projectId) return p
        const merged = { ...p, ...updates }
        // Phase changes no longer inflate avancement — actual tasks drive the number
        return merged
      }),
    }))
    sync(api.projects.update(projectId, updates))
  }, [updateStore])

  const inviteClientToProject = useCallback((projectId, clientEmail) => {
    if (!clientEmail || !clientEmail.includes('@')) return
    updateStore(prev => ({
      ...prev,
      projects: (prev.projects || []).map(p => p.id === projectId ? { ...p, clientEmail, clientInviteStatus: 'pending' } : p),
      projectInvitations: [...(prev.projectInvitations || []), {
        id: 'pinv_' + Date.now(),
        projectId,
        clientEmail,
        status: 'pending',
        sentBy: prev.user?.id,
        sentByName: prev.user?.name || prev.onboardingData?.entreprise || '',
        createdAt: new Date().toISOString(),
      }]
    }))
    addNotif('Invitation envoyée à ' + clientEmail, 'blue', null, 'projets')
    showToast('Invitation envoyée à ' + clientEmail, 'blue')
  }, [updateStore, addNotif, showToast])

  const respondProjectInvitation = useCallback((invitationId, accept) => {
    updateStore(prev => {
      const inv = (prev.projectInvitations || []).find(i => i.id === invitationId)
      if (!inv) return prev
      const newStatus = accept ? 'accepted' : 'refused'
      return {
        ...prev,
        projectInvitations: (prev.projectInvitations || []).map(i => i.id === invitationId ? { ...i, status: newStatus } : i),
        projects: (prev.projects || []).map(p => p.id === inv.projectId ? { ...p, clientInviteStatus: newStatus, clientId: accept ? (prev.user?.id || null) : p.clientId } : p),
      }
    })
    // Auto-membership: enregistrer le client comme membre du projet
    if (accept) {
      addProjectMember(
        (store.projectInvitations || []).find(i => i.id === invitationId)?.projectId,
        store.user?.id, ROLES.CLIENT, { userName: store.user?.name, userEmail: store.user?.email }
      )
    }
    addNotif(accept ? 'Vous avez accepté le projet' : 'Vous avez refusé l\'invitation', accept ? 'green' : 'orange')
    showToast(accept ? 'Projet accepté' : 'Invitation refusée', accept ? 'green' : 'orange')
  }, [store.user, store.projectInvitations, updateStore, addNotif, showToast, addProjectMember])

  // ── Missions ──
  const createMission = useCallback(async (missionData) => {
    const tempId = 'msn_' + Date.now()
    const optimistic = { id: tempId, ...missionData, createdBy: store.user?.id, createdAt: new Date().toISOString(), avancement: 0, jalons: [] }
    updateStore(prev => ({ ...prev, missions: [...(prev.missions || []), optimistic] }))
    try {
      const created = await api.missions.create(missionData)
      updateStore(prev => ({ ...prev, missions: (prev.missions || []).map(m => m.id === tempId ? { ...m, ...created } : m) }))
      log('MISSION_CREATED', { type: missionData.type, title: missionData.title })
      addNotif('Mission « ' + missionData.title + ' » créée', 'green', null, 'missions')
      showToast('Mission créée', 'green')
      return created
    } catch (e) {
      updateStore(prev => ({ ...prev, missions: (prev.missions || []).filter(m => m.id !== tempId) }))
      showToast(e.message || 'Erreur création mission', 'red')
      return null
    }
  }, [store.user, updateStore, log, addNotif, showToast])

  const updateMission = useCallback(async (missionId, data) => {
    updateStore(prev => ({
      ...prev,
      missions: (prev.missions || []).map(m => m.id === missionId ? { ...m, ...data } : m),
    }))
    try {
      const updated = await api.missions.update(missionId, data)
      updateStore(prev => ({
        ...prev,
        missions: (prev.missions || []).map(m => m.id === missionId ? { ...m, ...updated } : m),
      }))
      return updated
    } catch (e) {
      showToast(e.message || 'Erreur mise à jour mission', 'red')
      return null
    }
  }, [updateStore, showToast])

  const deleteMission = useCallback(async (missionId) => {
    updateStore(prev => ({
      ...prev,
      missions: (prev.missions || []).filter(m => m.id !== missionId),
    }))
    sync(api.missions.delete(missionId))
    log('MISSION_DELETED', { missionId })
    showToast('Mission supprimée')
  }, [updateStore, log, showToast])

  const updateMissionJalons = useCallback(async (missionId, jalons) => {
    const completed = jalons.filter(j => j.status === 'completed' || j.status === 'validated').length
    const avancement = jalons.length ? Math.round(completed / jalons.length * 100) : 0
    updateStore(prev => ({
      ...prev,
      missions: (prev.missions || []).map(m => m.id === missionId ? { ...m, jalons, avancement } : m),
    }))
    sync(api.missions.update(missionId, { jalons, avancement }))
  }, [updateStore])

  // ── Assets (Actifs du bâtiment) ──
  const createAsset = useCallback(async (data) => {
    try {
      const created = await api.assets.create(data)
      updateStore(prev => ({ ...prev, assets: [...(prev.assets || []), created] }))
      showToast('Actif créé', 'green')
      return created
    } catch (e) { showToast(e.message || 'Erreur', 'red'); return null }
  }, [updateStore, showToast])

  const updateAsset = useCallback(async (id, data) => {
    updateStore(prev => ({ ...prev, assets: (prev.assets || []).map(a => a.id === id ? { ...a, ...data } : a) }))
    sync(api.assets.update(id, data))
  }, [updateStore])

  const addMaintenance = useCallback(async (assetId, data) => {
    try {
      const updated = await api.assets.addMaintenance(assetId, data)
      updateStore(prev => ({ ...prev, assets: (prev.assets || []).map(a => a.id === assetId ? updated : a) }))
      showToast('Maintenance enregistrée', 'green')
      return updated
    } catch (e) { showToast(e.message || 'Erreur', 'red'); return null }
  }, [updateStore, showToast])

  // ── Passeport Numérique ──
  const generatePassport = useCallback(async (projectId) => {
    try {
      const passport = await api.passports.generate(projectId)
      updateStore(prev => ({ ...prev, passports: [...(prev.passports || []), passport] }))
      showToast('Passeport Numérique généré', 'green')
      addNotif('Passeport Numérique généré pour le projet', 'green', null, 'passport')
      return passport
    } catch (e) { showToast(e.message || 'Erreur', 'red'); return null }
  }, [updateStore, showToast, addNotif])

  // ── Clôture projet ──
  const requestCloture = useCallback((data) => {
    const req = {
      id: 'clot_' + Date.now(),
      projectId: data.projectId,
      requestedBy: store.user?.id || null,
      requestedByName: store.onboardingData?.entreprise || store.user?.name || '',
      clientId: data.clientId || null,
      clientEmail: data.clientEmail || null,
      clientPhone: data.clientPhone || null,
      validationMode: data.validationMode || 'PLATFORM', // PLATFORM | EXTERNAL_LINK | MANUAL
      status: data.validationMode === 'MANUAL' ? 'CLOTURE_VALIDE_EXTERNE' : 'EN_ATTENTE_VALIDATION_CLIENT',
      proof: data.proof || null,
      message: data.message || '',
      createdAt: new Date().toISOString(),
      validatedAt: data.validationMode === 'MANUAL' ? new Date().toISOString() : null,
    }
    updateStore(prev => {
      const projectStatus = data.validationMode === 'MANUAL' ? 'CLOTURE_VALIDE_EXTERNE' : 'DEMANDE_CLOTURE_ENVOYEE'
      // Si le projet n'est pas dans store.projects (projet statique), le copier
      const exists = (prev.projects || []).some(p => p.id === data.projectId)
      let projects = prev.projects || []
      if (exists) {
        projects = projects.map(p => p.id === data.projectId ? { ...p, clotureStatus: projectStatus, ...(data.validationMode === 'MANUAL' ? { status: 'archived' } : {}) } : p)
      } else {
        // Copier le projet statique dans le store avec le nouveau statut
        projects = [...projects, { id: data.projectId, clotureStatus: projectStatus, ...(data.validationMode === 'MANUAL' ? { status: 'archived' } : {}) }]
      }
      // Auto-compléter les missions liées au projet (jalons → completed, avancement → 100%)
      const missions = (prev.missions || []).map(m => {
        if (m.projectId !== data.projectId) return m
        const completedJalons = (m.jalons || []).map(j => ({ ...j, status: 'completed' }))
        return { ...m, status: 'completed', avancement: 100, jalons: completedJalons, completedAt: new Date().toISOString() }
      })
      return {
        ...prev,
        clotureRequests: [...(prev.clotureRequests || []), req],
        projects,
        missions,
      }
    })
    // Syncer le statut de clôture vers le backend
    const backendStatus = data.validationMode === 'MANUAL' ? 'CLOTURE_VALIDE_EXTERNE' : 'EN_ATTENTE_VALIDATION_CLIENT'
    api.projects.update(data.projectId, {
      clotureStatus: backendStatus,
      ...(data.validationMode === 'MANUAL' ? { status: 'archived' } : {}),
    }).then(res => console.log('[requestCloture] Backend sync OK:', res?.id, 'clotureStatus:', res?.clotureStatus))
      .catch(e => console.warn('[requestCloture] Backend sync FAILED:', e.message))
    // Auto-compléter les missions backend liées au projet
    const projMissions = (storeRef.current.missions || []).filter(m => m.projectId === data.projectId)
    projMissions.forEach(m => {
      api.missions?.update(m.id, { status: 'completed', avancement: 100, completedAt: new Date().toISOString() }).catch(() => {})
    })
    // Notifier le client via notification
    const proj = (storeRef.current.projects || []).find(p => p.id === data.projectId)
    if (proj?.clientId) {
      api.notifications.create({
        targetUserId: proj.clientId,
        type: 'cloture_request',
        message: `${store.onboardingData?.entreprise || store.user?.name || 'Le professionnel'} a déclaré le projet "${proj.nom || 'Projet'}" comme terminé. Confirmez la réception.`,
        link: '/client',
      }).catch(() => {})
    }
    if (data.validationMode === 'MANUAL') {
      addNotif('Projet clôturé avec validation externe', 'green', null, 'projets')
      showToast('Projet clôturé', 'green')
    } else if (data.validationMode === 'EXTERNAL_LINK') {
      addNotif('Lien de validation envoyé', 'blue', null, 'projets')
      showToast('Lien envoyé', 'blue')
    } else {
      addNotif('Demande de clôture envoyée', 'blue', null, 'projets')
      showToast('Demande envoyée', 'blue')
    }
    return req
  }, [store.user, store.onboardingData, updateStore, addNotif, showToast])

  const respondCloture = useCallback((clotureIdOrProjectId, accept, comment) => {
    // Supporte à la fois un clotureId (depuis clotureRequests) et un projectId direct (depuis proj.clotureStatus)
    let projectId = null
    updateStore(prev => {
      const req = (prev.clotureRequests || []).find(r => r.id === clotureIdOrProjectId)
      if (req) {
        projectId = req.projectId
      } else {
        // Fallback: clotureIdOrProjectId est un projectId ou un ID synthétique 'clot_<projectId>'
        projectId = clotureIdOrProjectId.startsWith?.('clot_') ? clotureIdOrProjectId.replace('clot_', '') : clotureIdOrProjectId
        // Vérifier que ce projectId existe
        if (!(prev.projects || []).some(p => p.id === projectId)) projectId = null
      }
      if (!projectId) return prev
      const newStatus = accept ? 'CLOTURE_VALIDE_EXTERNE' : 'CLOTURE_REFUSEE'
      return {
        ...prev,
        clotureRequests: (prev.clotureRequests || []).map(r => r.id === clotureIdOrProjectId ? { ...r, status: newStatus, validatedAt: new Date().toISOString(), clientComment: comment || '' } : r),
        projects: (prev.projects || []).map(p => p.id === projectId ? { ...p, clotureStatus: newStatus, ...(accept ? { status: 'completed' } : {}) } : p),
      }
    })
    // Syncer vers le backend
    if (projectId) {
      const newStatus = accept ? 'CLOTURE_VALIDE_EXTERNE' : 'CLOTURE_REFUSEE'
      api.projects.update(projectId, {
        clotureStatus: newStatus,
        ...(accept ? { status: 'completed' } : {}),
      }).catch(e => console.warn('[respondCloture] Backend sync failed:', e.message))
      // Notifier le pro
      const proj = (storeRef.current.projects || []).find(p => p.id === projectId)
      if (proj?.ownerId) {
        api.notifications.create({
          targetUserId: proj.ownerId,
          type: accept ? 'cloture_accepted' : 'cloture_refused',
          message: accept
            ? `Le client a confirmé la réception du projet "${proj.nom || 'Projet'}"`
            : `Le client a refusé la clôture du projet "${proj.nom || 'Projet'}"${comment ? ' — ' + comment : ''}`,
          link: '/cockpit',
        }).catch(() => {})
      }
    }
    const projName = (storeRef.current.projects || []).find(p => p.id === projectId)?.nom || 'Projet'
    if (accept) {
      emitEvent('project_completed', { projectName: projName }, { notifMsg: 'Projet \u00ab ' + projName + ' \u00bb terminé', notifType: 'green' })
    } else {
      addNotif('Clôture refusée', 'orange', null, 'projets')
    }
    showToast(accept ? 'Projet validé' : 'Clôture refusée', accept ? 'green' : 'orange')
  }, [updateStore, addNotif, showToast])

  // ── Invitations AO ──
  const sendAOInvitation = useCallback((data) => {
    // Guard: prevent duplicate email invites
    const inv = {
      id: 'aoinv_' + Date.now(),
      aoId: data.aoId,
      senderUserId: store.user?.id || null,
      targetUserId: data.targetUserId || null,
      targetEmail: data.targetEmail || null,
      targetPhone: data.targetPhone || null,
      targetName: data.targetName || '',
      targetTrade: data.targetTrade || '',
      message: data.message || '',
      status: 'sent',
      createdAt: new Date().toISOString(),
    }
    updateStore(prev => {
      // Prevent duplicate
      const exists = (prev.aoInvitations || []).some(i =>
        i.aoId === inv.aoId && ((i.targetEmail && i.targetEmail === inv.targetEmail) || (i.targetUserId && i.targetUserId === inv.targetUserId))
      )
      if (exists) return prev
      // If target is internal user, send notification
      const notifs = inv.targetUserId ? [
        ...prev.notifications,
        { id: Date.now(), msg: 'Vous avez été invité à répondre à un appel d\u2019offres', type: 'blue', link: null, page: 'bourse', read: false, ts: new Date().toISOString(), role: 'pro', aoId: inv.aoId }
      ] : prev.notifications
      return { ...prev, aoInvitations: [...(prev.aoInvitations || []), inv], notifications: notifs }
    })
    addNotif('Invitation envoyée' + (inv.targetName ? ' à ' + inv.targetName : ''), 'blue', null, 'bourse')
    showToast('Invitation envoyée', 'blue')
    return inv
  }, [store.user, updateStore, addNotif, showToast])

  /**
   * deleteAO — Suppression/annulation d'un AO avec règles métier
   * @returns {{ success: boolean, action?: string, reason?: string }}
   */
  const deleteAO = useCallback((aoId) => {
    const userId = store.user?.id
    const ao = (store.aos || []).find(a => a.id === aoId)
    if (!ao) return { success: false, reason: 'AO introuvable' }

    // Permission check
    if (ao.ownerUserId && String(ao.ownerUserId) !== String(userId)) {
      return { success: false, reason: 'Vous n\u2019êtes pas le propriétaire de cet AO' }
    }

    // Check if market was created from this AO
    const hasMarket = (store.markets || []).some(m => m.aoId === aoId)
    if (hasMarket) {
      return { success: false, reason: 'Cet appel d\u2019offres a déjà donné lieu à un marché', action: 'archive_only' }
    }

    // Check if responses exist
    const responses = (store.offers || []).filter(o => o.aoId === aoId)
    const hasResponses = responses.length > 0

    if (hasResponses) {
      // Cancel, don't hard delete
      updateStore(prev => ({
        ...prev,
        aos: (prev.aos || []).map(a => a.id === aoId ? { ...a, status: 'cancelled_by_owner', cancelledAt: new Date().toISOString() } : a),
        aoInvitations: (prev.aoInvitations || []).map(i => i.aoId === aoId && i.status === 'sent' ? { ...i, status: 'cancelled_with_ao' } : i),
      }))
      sync(api.aos.update(aoId, { status: 'cancelled_by_owner' }))
      log('AO_CANCELLED_BY_OWNER', { aoId, responses: responses.length })
      addNotif('Appel d\u2019offres annulé', 'orange', null, 'bourse')
      showToast('Appel d\u2019offres annulé', 'orange')
      return { success: true, action: 'cancelled' }
    }

    // Draft or published without responses — hard delete
    updateStore(prev => ({
      ...prev,
      aos: (prev.aos || []).filter(a => a.id !== aoId),
      aoInvitations: (prev.aoInvitations || []).map(i => i.aoId === aoId ? { ...i, status: 'cancelled_with_ao' } : i),
    }))
    sync(api.aos.delete(aoId))
    log('AO_DELETED', { aoId })
    addNotif('Appel d\u2019offres supprimé', 'info', null, 'bourse')
    showToast('Appel d\u2019offres supprimé', 'info')
    return { success: true, action: 'deleted' }
  }, [store.user, store.aos, store.offers, store.markets, updateStore, log, addNotif, showToast])

  const updateAO = useCallback((aoId, updates) => {
    const ao = (store.aos || []).find(a => a.id === aoId)
    if (!ao) return { success: false, reason: 'AO introuvable' }
    if (ao.ownerUserId && ao.ownerUserId !== store.user?.id) {
      return { success: false, reason: 'Vous n\u2019êtes pas le propriétaire de cet AO' }
    }
    // Only allow editing open AOs
    if (ao.status !== 'open') {
      return { success: false, reason: 'Seul un AO ouvert peut être modifié' }
    }
    const allowed = ['title', 'description', 'budget', 'lot', 'requestedTrade', 'visibilityScope']
    const clean = {}
    for (const k of allowed) { if (updates[k] !== undefined) clean[k] = updates[k] }
    updateStore(prev => ({
      ...prev,
      aos: (prev.aos || []).map(a => a.id === aoId ? { ...a, ...clean, updatedAt: new Date().toISOString() } : a),
    }))
    sync(api.aos.update(aoId, clean))
    log('AO_UPDATED', { aoId, fields: Object.keys(clean) })
    showToast('Appel d\u2019offres mis à jour')
    return { success: true }
  }, [store.user, store.aos, updateStore, log, showToast])

  const archiveAO = useCallback((aoId) => {
    updateStore(prev => ({
      ...prev,
      aos: (prev.aos || []).map(a => a.id === aoId ? { ...a, status: 'archived', archivedAt: new Date().toISOString() } : a),
    }))
    sync(api.aos.update(aoId, { status: 'archived' }))
    log('AO_ARCHIVED', { aoId })
    showToast('Appel d\u2019offres archivé', 'info')
  }, [updateStore, log, showToast])

  const createAO = useCallback(async (data) => {
    // Use storeRef for fresh values (avoids stale closure after createUser)
    const currentUser = storeRef.current.user
    const currentMembers = storeRef.current.projectMembers || []
    const userType = currentUser?.type
    const projectRole = data.projectId
      ? getProjectRole(currentUser?.id, data.projectId, currentMembers, currentUser)
      : (userType === 'client' ? ROLES.CLIENT : userType === 'pro' ? ROLES.PRO_ADMIN : null)
    // Skip permission check for auto-generated AOs (created by system during onboarding)
    if (!data.autoGenerated && !isAllowed(projectRole, 'create_ao')) {
      showToast('Vous n\'êtes pas autorisé à créer un appel d\'offres', 'orange')
      return null
    }
    const tempId = 'ao_' + Date.now()
    const aoPayload = {
      title: data.title || data.titre || "Appel d'offres",
      description: data.description || '',
      budget: data.budget || '',
      lot: data.lot || '',
      status: 'open',
      projectId: data.projectId || null,
      ownerUserId: currentUser?.id || null,
      ownerProfileType: currentUser?.type || data.ownerProfileType || 'client',
      requestedTrade: data.requestedTrade || data.lot || '',
      visibilityScope: data.visibilityScope || 'public',
      createdByClient: data.createdByClient || (currentUser?.type === 'client'),
      deadline: data.deadline || '',
      prive: data.prive || false,
      listeRestreinte: data.listeRestreinte || [],
    }
    // Optimistic update — add to store immediately so the AO appears without waiting
    const tempAO = {
      ...aoPayload,
      id: tempId,
      ownerRole: projectRole,
      autoGenerated: data.autoGenerated || false,
      createdAt: new Date().toISOString(),
    }
    updateStore(prev => ({ ...prev, aos: [...(prev.aos || []), tempAO] }))
    log('AO_CREATED', { title: tempAO.title, trade: tempAO.requestedTrade, visibility: tempAO.visibilityScope, projectRole })
    emitEvent('ao_published', { title: tempAO.title }, { notifMsg: 'AO \u00ab ' + tempAO.title + " \u00bb publi\u00e9 \u2014 en attente d'offres", notifType: 'blue' })
    showToast("\ud83d\udce3 Appel d'offres publi\u00e9", 'blue')
    // Persist to backend and replace temp ID with real ID
    try {
      const backendAO = await api.aos.create(aoPayload)
      updateStore(prev => ({
        ...prev,
        aos: prev.aos.map(a => a.id === tempId
          ? { ...a, id: backendAO.id, createdAt: backendAO.createdAt || a.createdAt }
          : a
        ),
      }))
      return { ...tempAO, id: backendAO.id }
    } catch (e) {
      // Backend échoué — rollback: retirer l'AO local fantôme
      console.warn('[createAO] Backend failed, rolling back local AO:', e.message)
      updateStore(prev => ({ ...prev, aos: (prev.aos || []).filter(a => a.id !== tempId) }))
      showToast('Erreur lors de la création de l\'AO — réessayez', 'red')
      return null
    }
  }, [updateStore, log, addNotif, showToast])

  const submitOffer = useCallback(async (data) => {
    // Guard: seuls les prestataires (entreprise, BET, fournisseur) peuvent répondre
    const userType = store.user?.type
    const ao = (store.aos || []).find(a => a.id === data.aoId)
    const projectRole = ao?.projectId
      ? getProjectRole(store.user?.id, ao.projectId, store.projectMembers, store.user)
      : (userType === 'pro' ? ROLES.ENTREPRISE : userType === 'fournisseur' ? ROLES.SUPPLIER : null)
    if (!isAllowed(projectRole, 'respond_ao')) {
      showToast('Seuls les professionnels peuvent répondre à un appel d\'offres', 'orange')
      return null
    }
    // Guard: ne pas répondre à son propre AO
    if (ao && ao.ownerUserId === store.user?.id) {
      showToast('Vous ne pouvez pas répondre à votre propre appel d\'offres', 'orange')
      return null
    }
    const offerPayload = {
      titre: data.entreprise || store.onboardingData?.entreprise || store.user?.company || '',
      entreprise: data.entreprise || store.onboardingData?.entreprise || store.user?.company || '',
      montant: String(data.price || data.montant || 0),
      delai: data.delai || '',
      message: data.message || '',
      technique: data.technique || '',
      docs: Array.isArray(data.docs) ? data.docs : [],
      statut: 'pending',
      aoId: data.aoId,
      userId: store.user?.id || data.supplierId,
      supplierId: store.user?.id || data.supplierId || null,
      supplierRole: projectRole || null,
    }
    // Create on backend FIRST — get real ID
    let offer
    try {
      const backendOffer = await api.offers.create(offerPayload)
      offer = {
        id: backendOffer.id,
        aoId: data.aoId,
        supplierId: store.user?.id || data.supplierId,
        supplierRole: projectRole,
        entreprise: offerPayload.entreprise,
        supplierName: offerPayload.entreprise,
        price: data.price || data.montant || 0,
        montant: offerPayload.montant,
        delai: data.delai || '',
        message: data.message || '',
        technique: data.technique || '',
        docs: offerPayload.docs,
        status: 'pending',
        statut: 'pending',
        createdAt: backendOffer.createdAt || new Date().toISOString(),
      }
    } catch (e) {
      // 409 = déjà postulé sur cet AO (contrainte unique aoId+supplierId)
      if (e.status === 409 || (e.message || '').includes('Unique constraint') || (e.message || '').includes('déjà postulé')) {
        showToast('Vous avez déjà soumis une offre pour cet AO', 'orange')
        return null
      }
      console.warn('[submitOffer] Backend failed:', e.message)
      showToast('Erreur lors de la soumission — réessayez', 'red')
      return null
    }
    updateStore(prev => ({ ...prev, offers: [...prev.offers, offer] }))
    log('OFFER_SUBMITTED', { aoId: offer.aoId, price: offer.price, supplierRole: projectRole })
    addNotif('Offre soumise \u2014 en attente de r\u00e9ponse', 'info', null, 'offres')
    showToast('\ud83d\udce9 Offre envoy\u00e9e avec succ\u00e8s', 'green')
    return offer
  }, [store.user, store.aos, store.projectMembers, updateStore, log, addNotif, showToast])

  const acceptOffer = useCallback((offerId) => {
    // Guard: seul le client ou architecte mandaté peut accepter
    const ao = (() => {
      const offer = (store.offers || []).find(o => o.id === offerId)
      return offer ? (store.aos || []).find(a => a.id === offer.aoId) : null
    })()
    const projectRole = ao?.projectId
      ? getProjectRole(store.user?.id, ao.projectId, store.projectMembers, store.user)
      : (store.user?.type === 'client' ? ROLES.CLIENT : store.user?.type === 'pro' ? ROLES.PRO_ADMIN : null)
    if (!isAllowed(projectRole, 'accept_offer')) {
      showToast('Seul le maître d\'ouvrage ou l\'architecte mandaté peut accepter une offre', 'orange')
      return null
    }

    let market = null
    updateStore(prev => {
      const offer = (prev.offers || []).find(o => o.id === offerId)
      if (!offer) return prev
      const offers = (prev.offers || []).map(o => {
        if (o.aoId === offer.aoId && o.id !== offerId) return { ...o, status: 'rejected', statut: 'rejected' }
        if (o.id === offerId) return { ...o, status: 'accepted', statut: 'accepted', acceptedBy: prev.user?.id, acceptedAt: new Date().toISOString() }
        return o
      })
      const aoObj = (prev.aos || []).find(a => a.id === offer.aoId)
      // If AO has no project, auto-create one from the market context
      let autoProject = null
      let projectId = aoObj?.projectId || null
      if (!projectId) {
        const pId = 'proj_' + Date.now()
        projectId = pId
        // Nettoyer le titre de l'AO des préfixes auto-générés ("Recherche architecte ·", "Mission complète ·")
        const cleanTitle = (aoObj?.title || '').replace(/^(Recherche\s+\w+\s*[·•]\s*|Mission\s+compl[eè]te\s*[·•]\s*)/i, '').trim()
        const projNom = cleanTitle || aoObj?.lot || offer.entreprise || 'Nouveau projet'
        autoProject = {
          id: pId,
          nom: projNom,
          type: aoObj?.lot || 'Mission',
          phase: 'ATTRIBUTION_MARCHES',
          budget: offer.price ? String(offer.price) : offer.montant ? String(offer.montant) : aoObj?.budget || '',
          adresse: '',
          description: aoObj?.description || '',
          avancement: 0,
          status: 'active',
          ownerId: prev.user?.id || 'local',
          clientId: aoObj?.ownerUserId || null,
          // Look up client name/email from linked project (don't use current user who may be the supplier)
          clientEmail: (aoObj?.projectId ? (prev.projects || []).find(p => p.id === aoObj.projectId)?.clientEmail : '') || '',
          client: (aoObj?.projectId ? (prev.projects || []).find(p => p.id === aoObj.projectId)?.client : '') || '',
          color: '#2563EB',
          createdAt: new Date().toISOString(),
          // Link back to AO and market
          sourceAoId: offer.aoId,
          etapes: [
            { n: 'Préparation', label: 'Préparation & mobilisation', done: false, current: true },
            { n: 'Installation', label: 'Installation chantier', done: false },
            { n: 'Exécution', label: 'Exécution des travaux', done: false },
            { n: 'Contrôle', label: 'Contrôle qualité', done: false },
            { n: 'Livraison', label: 'Livraison & réception', done: false },
          ],
          equipe: [{ nom: offer.entreprise || offer.supplierName || '', role: aoObj?.lot || 'Intervenant', statut: 'actif' }],
        }
      }
      // Heritage complet AO + Offre → Marche avec acteurs identifiés
      market = {
        id: 'mkt_' + Date.now(),
        projectId: projectId,
        aoId: offer.aoId,
        // ═══ ACTEURS CONTRACTUELS ═══
        clientId: aoObj?.ownerProfileType === 'client' ? aoObj?.ownerUserId : (prev.projects || []).find(p => p.id === aoObj?.projectId)?.clientId || null,
        supplierId: offer.supplierId,
        supplierRole: offer.supplierRole || null,
        acceptedBy: prev.user?.id || null,
        acceptedByRole: projectRole,
        aoOwnerId: aoObj?.ownerUserId || null,
        // Heritage AO
        lot: aoObj?.lot || aoObj?.title || '',
        titre: aoObj?.title || '',
        budget: aoObj?.budget || '',
        description: aoObj?.description || '',
        // Heritage Offre — montant depuis Prisma ou price depuis store local
        amount: offer.price || offer.montant || 0,
        montant: String(offer.price || offer.montant || 0),
        entreprise: offer.entreprise || offer.supplierName || '',
        // Client info — resolved from linked project; never fall back to current user (who is the supplier)
        clientName: (() => { const lp = aoObj?.projectId ? (prev.projects || []).find(p => p.id === aoObj.projectId) : null; return lp?.client || aoObj?.ownerName || '' })(),
        clientCompany: (() => { const lp = aoObj?.projectId ? (prev.projects || []).find(p => p.id === aoObj.projectId) : null; return lp?.client || '' })(),
        clientEmail: (() => { const lp = aoObj?.projectId ? (prev.projects || []).find(p => p.id === aoObj.projectId) : null; return lp?.clientEmail || '' })(),
        offerMessage: offer.message || '',
        // Statut & cycle de vie
        statut: 'signed',
        progress: 0,
        status: 'ongoing',
        milestones: [],
        documents: [],
        validations: [],
        delai: offer.delai || '',
        createdAt: new Date().toISOString()
      }
      const defaultTasks = ['Pr\u00e9paration & mobilisation', 'Installation chantier', 'Ex\u00e9cution travaux', 'Contr\u00f4le qualit\u00e9', 'Livraison & r\u00e9ception']
      const tasks = defaultTasks.map((title, i) => ({
        id: 'task_' + Date.now() + '_' + i,
        marketId: market.id,
        projectId: market.projectId,
        title,
        status: 'pending',
        progress: 0,
        assignedTo: offer.supplierId || null,
        assignedRole: offer.supplierRole || null,
      }))
      // Propager evenement marche vers agenda
      const mktEvt = {
        id: 'evt_mkt_' + market.id,
        title: 'Marché signé — ' + (market.lot || market.titre || 'Nouveau marché'),
        date: new Date().toISOString().slice(0, 10),
        type: 'milestone',
        projectId: market.projectId,
        color: '#34C759',
        auto: true,
      }
      // Auto-membership: ajouter le prestataire au projet
      let newMembers = prev.projectMembers || []
      if (market.projectId && offer.supplierId) {
        const alreadyMember = newMembers.some(m => m.projectId === market.projectId && m.userId === offer.supplierId)
        if (!alreadyMember) {
          newMembers = [...newMembers, {
            id: 'pm_' + Date.now() + '_mkt',
            projectId: market.projectId,
            userId: offer.supplierId,
            role: offer.supplierRole || ROLES.ENTREPRISE,
            userName: offer.entreprise || offer.supplierName || '',
            joinedAt: new Date().toISOString(),
          }]
        }
      }
      // Close the AO — offer accepted, mark as attributed (not just closed)
      const closedAos = (prev.aos || []).map(a =>
        a.id === offer.aoId ? { ...a, status: 'attributed', closedAt: new Date().toISOString() } : a
      )
      const nextProjects = autoProject ? [...prev.projects, autoProject] : prev.projects.map(p =>
        // Mettre à jour la phase du projet existant quand une offre est acceptée
        p.id === projectId ? { ...p, phase: p.phase === 'ATTRIBUTION_MARCHES' || p.phase === 'CONSULTATION_ENTREPRISES' ? 'SUIVI_CHANTIER' : p.phase, status: 'active', avancement: Math.max(p.avancement || 0, 5) } : p
      )
      // Auto-create conversation between client and pro after market signing
      const autoConv = {
        id: 'conv_' + Date.now(),
        projectId: projectId,
        marketId: market.id,
        isGroup: true,
        participants: [prev.user?.id, offer.supplierId].filter(Boolean),
        title: (aoObj?.title || 'Projet') + ' — ' + (offer.entreprise || ''),
        nom: offer.entreprise || offer.supplierName || aoObj?.title || 'Conversation',
        lastMessage: 'Marché signé — la conversation est ouverte.',
        lastAt: new Date().toISOString(),
        unread: 0,
      }
      return { ...prev, offers, aos: closedAos, projects: nextProjects, markets: [...prev.markets, market], tasks: [...prev.tasks, ...tasks], events: [...(prev.events || []), mktEvt], projectMembers: newMembers, conversations: [...(prev.conversations || []), autoConv] }
    })
    // Sync to PostgreSQL — project, market, offer, AO, event (all in async block)
    const closedAoId = (store.offers || []).find(o => o.id === offerId)?.aoId
    const isLocalId = (id) => typeof id === 'string' && id.startsWith('proj_')
    ;(async () => {
      let backendProjectId = market?.projectId
      try {
        if (market?.projectId && !ao?.projectId) {
          try {
            const autoProj = storeRef.current.projects?.find(p => p.id === market.projectId)
            const backendProject = await api.projects.create({
              nom: autoProj?.nom || market.titre || 'Projet', type: market.lot || 'Mission',
              phase: 'ATTRIBUTION_MARCHES', budget: String(market.amount || market.budget || ''),
              description: market.description || '', status: 'active',
              ownerId: store.user?.id || null, clientId: market?.clientId || null,
              clientEmail: market?.clientEmail || '', client: market?.clientName || '',
              sourceAoId: market.aoId || null,
              etapes: autoProj?.etapes || null, equipe: autoProj?.equipe || null,
            })
            if (backendProject?.id) {
              backendProjectId = backendProject.id
              // Replace local proj_ ID with backend cuid
              updateStore(prev => ({
                ...prev,
                projects: (prev.projects || []).map(p => p.id === market.projectId ? { ...p, id: backendProject.id } : p)
              }))
              console.log('[acceptOffer] Auto-project synced:', backendProject.id)
            }
          } catch (e) {
            console.warn('[acceptOffer] Project sync failed:', e.message)
            showToast('Erreur création projet: ' + e.message, 'red')
          }
        }
        // Si le projet n'a pas pu être créé en backend, retenter une fois
        if (isLocalId(backendProjectId)) {
          console.warn('[acceptOffer] Project ID is local-only, retrying...')
          try {
            const autoProj = storeRef.current.projects?.find(p => p.id === backendProjectId)
            const retryProject = await api.projects.create({
              nom: autoProj?.nom || market?.titre || 'Projet', type: market?.lot || 'Mission',
              phase: 'ATTRIBUTION_MARCHES', budget: String(market?.amount || market?.budget || ''),
              description: market?.description || '', status: 'active',
              ownerId: store.user?.id || null, clientId: market?.clientId || null,
              clientEmail: market?.clientEmail || '', client: market?.clientName || '',
              sourceAoId: market?.aoId || null,
            })
            if (retryProject?.id) {
              backendProjectId = retryProject.id
              updateStore(prev => ({
                ...prev,
                projects: (prev.projects || []).map(p => p.id === market?.projectId ? { ...p, id: retryProject.id } : p)
              }))
            }
          } catch (_) { /* retry failed */ }
        }
        // Si toujours local après retry, sync uniquement offre/AO
        if (isLocalId(backendProjectId)) {
          console.warn('[acceptOffer] Skipping market/project sync — project ID is local-only:', backendProjectId)
          sync(api.offers.update(offerId, { statut: 'accepted', acceptedBy: store.user?.id || null, acceptedAt: new Date().toISOString() }))
          if (closedAoId) sync(api.aos.update(closedAoId, { status: 'attributed' }))
          return
        }
        // 2. Create market on backend with real projectId
        const backendMarket = await api.markets.create({ titre: market?.titre, entreprise: market?.entreprise, lot: market?.lot, montant: String(market?.amount || market?.montant || market?.budget || ''), statut: 'signed', avancement: 0, projectId: backendProjectId, offerId, aoId: market?.aoId || null, clientId: market?.clientId || null, supplierId: market?.supplierId || null, delai: market?.delai || null, description: market?.description || null })
        // Replace local mkt_ ID with backend cuid
        if (backendMarket?.id && market) {
          updateStore(prev => ({
            ...prev,
            markets: (prev.markets || []).map(m => m.id === market.id ? { ...m, id: backendMarket.id } : m)
          }))
        }
        // 3. Immediately re-sync projects & markets so both client and pro see fresh data
        const [freshProjects, freshMarkets] = await Promise.all([
          api.projects.getAll().catch(() => null),
          api.markets.getAll().catch(() => null),
        ])
        if (freshProjects || freshMarkets) {
          setStore(prev => {
            const next = {
              ...prev,
              ...(freshProjects ? { projects: freshProjects } : {}),
              ...(freshMarkets ? { markets: freshMarkets } : {}),
            }
            saveToStorage(next)
            return next
          })
        }
      } catch (e) {
        console.warn('[acceptOffer] Market sync failed:', e.message)
        showToast('Erreur création marché: ' + e.message, 'red')
      }
      // Sync remaining entities (fire-and-forget)
      sync(api.offers.update(offerId, { statut: 'accepted', acceptedBy: store.user?.id || null, acceptedAt: new Date().toISOString() }))
      if (closedAoId) sync(api.aos.update(closedAoId, { status: 'attributed' }))
      sync(api.events.create({ titre: 'Marché signé — ' + (market?.lot || market?.titre || 'Nouveau marché'), date: new Date().toISOString().slice(0, 10), type: 'milestone', projectId: backendProjectId || market?.projectId, color: '#34C759' }))
      // Sync auto-conversation to backend — toujours en groupe pour les conversations projet
      const supplierId = market?.supplierId
      const autoConvData = storeRef.current.conversations?.find(c => c.marketId === market?.id)
      console.log('[acceptOffer] supplierId:', supplierId, '| market:', market?.id, '| user:', storeRef.current.user?.id)
      if (!supplierId) console.warn('[acceptOffer] ⚠ supplierId manquant — la conversation ne sera pas créée côté backend')
      if (supplierId) {
        try {
          const convTitle = autoConvData?.title || (market?.titre || 'Projet') + ' — ' + (market?.entreprise || '')
          // Vérifier si d'autres membres du projet doivent être inclus
          const extraMembers = (storeRef.current.projectMembers || [])
            .filter(pm => pm.projectId === (backendProjectId || market?.projectId) && pm.userId !== storeRef.current.user?.id && pm.userId !== supplierId)
            .map(pm => pm.userId)
            .filter(Boolean)
          const convProjectId = backendProjectId || market?.projectId || null
          // ARBITRAGE v1.52 (MSG-04/MSG-08) : « fusion tant qu'il n'y a qu'un
          // professionnel, séparation dès le premier intervenant ».
          // Titulaire seul → AUCUN groupe : le fil direct 1:1 sert de fil de
          // projet. S'il existe déjà, le serveur (pairHash unique) le renvoie.
          // Des intervenants existent déjà → groupe projet, créé de façon
          // idempotente par projectId côté serveur (MSG-08).
          let convRes
          if (extraMembers.length === 0) {
            console.log('[acceptOffer] Titulaire seul → fil direct 1:1 (aucun groupe créé)')
            convRes = await api.conversations.create({ participantId: supplierId, projectId: convProjectId })
          } else {
            console.log('[acceptOffer] Intervenants présents → groupe projet:', [supplierId, ...extraMembers])
            convRes = await api.conversations.create({ participantIds: [supplierId, ...extraMembers], title: convTitle, projectId: convProjectId, type: 'projet' })
          }
          const backendConv = convRes?.conversation || convRes
          console.log('[acceptOffer] Backend conv created:', backendConv?.id, '| participants:', backendConv?.participants?.length)
          if (backendConv?.id) {
            updateStore(prev => {
              // Supprimer le local autoConv et tout doublon de la conversation backend
              const withoutLocal = (prev.conversations || []).filter(c => c.id !== autoConvData?.id && c.id !== backendConv.id)
              const shaped = {
                id: backendConv.id,
                nom: backendConv.title || autoConvData?.nom || convTitle,
                isGroup: !!backendConv.isGroup,
                participants: (backendConv.participants || []).map(p => p.user?.id || p.userId).filter(Boolean),
                title: backendConv.title || convTitle,
                marketId: market?.id,
                projectId: backendProjectId || market?.projectId,
                dernier: 'Marché signé — la conversation est ouverte.',
                lastMessage: null,
                unread: 0,
              }
              return { ...prev, conversations: [shaped, ...withoutLocal] }
            })
          }
          // Re-fetch conversations immediately so the list shows the new conversation
          api.conversations.getAll().then(res => {
            const list = Array.isArray(res) ? res : (res?.conversations || [])
            if (list.length > 0) {
              setStore(prev => {
                const next = { ...prev, conversations: list }
                saveToStorage(next)
                return next
              })
            }
          }).catch(() => {})
        } catch (e) {
          console.warn('[acceptOffer] Conversation sync failed:', e.message)
        }
      }
      // Sync project member (supplier added to project team)
      const offer = storeRef.current.offers?.find(o => o.id === offerId)
      if (offer?.supplierId && (backendProjectId || market?.projectId)) {
        sync(api.projectMembers.create({ projectId: backendProjectId || market.projectId, userId: offer.supplierId, role: offer.supplierRole || 'ENTREPRISE', userName: offer.entreprise || '' }))
      }
    })()
    log('OFFER_ACCEPTED', { offerId, acceptedByRole: projectRole })
    emitEvent('offer_accepted', { title: ao?.title || ao?.titre || '', offerId }, { notifMsg: 'Offre acceptée — marché en cours de création', notifType: 'green' })
    showToast('Offre acceptée', 'green')
    // ── Commission clé en main : créer introduction + commission si applicable ──
    if (_isCEM && _isCEM(storeRef.current) && market) {
      const offer = storeRef.current.offers?.find(o => o.id === offerId)
      if (offer) {
        const intro = {
          id: 'intro_' + Date.now(),
          projectId: market.projectId,
          clientId: storeRef.current.user?.id,
          structureId: offer.supplierId,
          structureName: offer.entreprise || offer.supplierName || '',
          metier: market.lot || '',
          status: 'retained',
          introDate: new Date().toISOString(),
          retainedAt: new Date().toISOString(),
          source: 'meereo_cle_en_main',
        }
        const calc = _calcComm ? _calcComm(market.amount || market.budget) : { base: 0, amount: 0, rate: 0.05 }
        const commission = {
          id: 'comm_' + Date.now(),
          introductionId: intro.id,
          structureId: offer.supplierId,
          structureName: intro.structureName,
          projectId: market.projectId,
          clientId: storeRef.current.user?.id,
          montantBase: calc.base,
          montantCommission: calc.amount,
          rate: calc.rate,
          status: 'pending',
          createdAt: new Date().toISOString(),
          paidAt: null,
        }
        updateStore(prev => ({
          ...prev,
          introductions: [...(prev.introductions || []), intro],
          commissions: [...(prev.commissions || []), commission],
        }))
        sync(api.introductions.create({ projectId: intro.projectId, clientId: intro.clientId, structureId: intro.structureId, structureName: intro.structureName, metier: intro.metier, status: intro.status, source: intro.source }))
        sync(api.commissionsTracking.create({ introductionId: intro.id, structureId: commission.structureId, structureName: commission.structureName, projectId: commission.projectId, montantBase: commission.montantBase, montantCommission: commission.montantCommission, rate: commission.rate, status: commission.status }))
        log('COMMISSION_CLE_EN_MAIN', { structureName: intro.structureName, amount: commission.montantCommission })
      }
    }
    return market
  }, [store.user, store.offers, store.aos, store.projectMembers, updateStore, log, addNotif, showToast])

  // Émettre un événement métier (notif + log + badge update)
  const emitEvent = useCallback((eventType, data = {}, opts = {}) => {
    log(eventType, data)
    if (opts.notifMsg) {
      addNotif(opts.notifMsg, opts.notifType || 'info', opts.notifLink || null)
    }
    if (opts.toast) {
      showToast(opts.toast, opts.toastColor || 'info')
    }
    // Dispatch custom DOM event for cross-component reactivity
    window.dispatchEvent(new CustomEvent('meereo-event', { detail: { type: eventType, data, ts: Date.now() } }))
  }, [log, addNotif, showToast])

  const rejectOffer = useCallback((offerId) => {
    updateStore(prev => ({
      ...prev,
      offers: (prev.offers || []).map(o => o.id === offerId ? { ...o, status: 'rejected', statut: 'rejected' } : o)
    }))
    sync(api.offers.update(offerId, { statut: 'rejected' }))
    log('OFFER_REJECTED', { offerId })
    const rejectedOffer = storeRef.current.offers?.find(o => o.id === offerId)
    emitEvent('offer_rejected', { title: rejectedOffer?.titre || '', offerId }, { notifMsg: 'Offre refusée', notifType: 'orange' })
    showToast('\u274c Offre refus\u00e9e', 'orange')
  }, [updateStore, log, showToast, emitEvent])

  const triggerPayment = useCallback((data) => {
    // Guard: seul le client peut initier un paiement
    const userType = store.user?.type
    if (userType !== 'client' && !data._systemGenerated) {
      const role = data.projectId ? getProjectRole(store.user?.id, data.projectId, store.projectMembers, store.user) : null
      if (!isAllowed(role, 'initiate_payment')) {
        showToast('Seul le maître d\'ouvrage peut initier un paiement', 'orange')
        return null
      }
    }
    const tx = {
      id: 'tx_' + Date.now(),
      projectId: data.projectId,
      marketId: data.marketId || null,
      amount: data.amount || 0,
      type: data.type || 'payment',
      paymentType: data.paymentType || 'paiement', // 'appel_de_fonds' | 'paiement' | 'acompte'
      status: 'pending',
      label: data.label || 'Paiement',
      // ═══ ACTEURS FINANCIERS ═══
      fromUserId: store.user?.id || data.fromUserId || null,
      toUserId: data.toUserId || null,
      fromRole: data.fromRole || (userType === 'client' ? ROLES.CLIENT : null),
      toRole: data.toRole || null,
      initiatedBy: store.user?.id || null,
      createdAt: new Date().toISOString()
    }
    updateStore(prev => ({ ...prev, transactions: [...prev.transactions, tx] }))
    sync(api.transactions.create({ type: tx.type || 'payment', label: tx.label, montant: tx.amount, statut: tx.status, projectId: tx.projectId, marketId: tx.marketId, fromUserId: tx.fromUserId, toUserId: tx.toUserId, fromRole: tx.fromRole, toRole: tx.toRole }))
    log('PAYMENT_TRIGGERED', { amount: tx.amount, fromUserId: tx.fromUserId, toUserId: tx.toUserId, paymentType: tx.paymentType })
    addNotif('Paiement de ' + formatAmount(tx.amount) + ' initi\u00e9', 'blue', null, 'paiements')
    showToast('\ud83d\udcb0 Paiement de ' + formatAmount(tx.amount) + ' initi\u00e9', 'blue')
    return tx
  }, [store.user, store.projectMembers, updateStore, log, addNotif, showToast])

  const confirmPayment = useCallback((txId) => {
    updateStore(prev => ({
      ...prev,
      transactions: (prev.transactions || []).map(t => t.id === txId ? { ...t, status: 'confirmed' } : t)
    }))
    sync(api.transactions.update(txId, { statut: 'confirmed' }))
    log('PAYMENT_CONFIRMED', { txId })
    addNotif('Paiement confirm\u00e9 \u2713', 'green', null, 'paiements')
    showToast('\u2705 Paiement confirm\u00e9', 'green')
  }, [updateStore, log, addNotif, showToast])

  const uploadDocument = useCallback((data) => {
    const doc = {
      id: 'doc_' + Date.now(),
      projectId: data.projectId,
      type: data.type || 'general',
      name: data.name || 'Document',
      url: data.url || '',
      uploadedBy: store.user?.id || null,
      createdAt: new Date().toISOString()
    }
    updateStore(prev => ({ ...prev, documents: [...prev.documents, doc] }))
    sync(api.documents.create({ name: doc.name, type: doc.type, url: doc.url, projectId: doc.projectId, userId: doc.uploadedBy }))
    log('DOCUMENT_UPLOADED', { name: doc.name })
    addNotif('Document \u00ab ' + doc.name + ' \u00bb ajout\u00e9', 'info', null, 'documents')
    showToast('\ud83d\udcce Document ajout\u00e9', 'info')
    return doc
  }, [store.user, updateStore, log, addNotif, showToast])

  const addProduct = useCallback((data) => {
    // Use storeRef for fresh user (avoids stale closure after createUser)
    const currentUser = storeRef.current.user
    const product = {
      id: 'prod_' + Date.now(),
      supplierId: data.supplierId || currentUser?.id || null,
      sellerId: data.sellerId || currentUser?.id || null,
      name: data.name || data.nom || '',
      category: data.category || data.categorie || '',
      price: data.price || data.prix || 0,
      unit: data.unit || 'unite',
      description: data.description || '',
      photoUrl: data.photoUrl || null,
      stock: data.stock || null,
      isPublished: data.isPublished !== undefined ? data.isPublished : true,
      sponsored: data.sponsored || false,
      flash: data.flash || false,
      flashPrice: data.flashPrice || null,
      flashDuration: data.flashDuration || null,
      status: data.status || 'active',
      source: data.source || 'fournisseur',
      marketplace: data.marketplace !== undefined ? data.marketplace : true,
      createdAt: new Date().toISOString()
    }
    updateStore(prev => ({ ...prev, products: [...prev.products, product] }))
    // POST vers PostgreSQL — produit partagé entre tous les utilisateurs
    api.products.create({
      name: product.name,
      category: product.category,
      price: product.price,
      unit: product.unit,
      description: product.description,
      photoUrl: product.photoUrl || null,
      stock: product.stock || 0,
      isPublished: product.isPublished,
      sponsored: product.sponsored,
      flash: product.flash,
      flashPrice: product.flashPrice || null,
    }).then(saved => {
      // Remplacer l'ID local par l'ID PostgreSQL + refléter le statut de publication réel
      // (MKT-06g : le serveur peut forcer le brouillon si le quota gratuit est dépassé)
      if (saved?.id) {
        updateStore(prev => ({
          ...prev,
          products: prev.products.map(p => p.id === product.id
            ? { ...p, id: saved.id, isPublished: saved.isPublished }
            : p),
        }))
      }
      if (saved?.isOverQuota) {
        showToast('⚠️ Quota gratuit atteint (5 produits) — ce produit reste en brouillon jusqu’à souscription d’un forfait', 'orange')
      }
    }).catch(e => console.warn('[addProduct] Backend sync failed:', e.message))
    log('PRODUCT_ADDED', { name: product.name })
    showToast('\ud83d\udce6 Produit ajout\u00e9 au catalogue', 'green')
    return product
  }, [store.user, updateStore, log, showToast])

  const updateMarketProgress = useCallback((marketId, value) => {
    updateStore(prev => {
      const markets = (prev.markets || []).map(m => {
        if (m.id !== marketId) return m
        const progress = Math.max(0, Math.min(100, value))
        return { ...m, progress, status: progress >= 100 ? 'completed' : m.status }
      })
      return { ...prev, markets }
    })
    sync(api.markets.update(marketId, { avancement: Math.max(0, Math.min(100, value)) }))
    log('MARKET_PROGRESS', { marketId, value })
    showToast('\ud83d\udcca Avancement mis \u00e0 jour : ' + value + '%', 'info')
  }, [updateStore, log, showToast])

  const resetStore = useCallback(() => {
    updateStore({ ...defaultStore })
  }, [updateStore])

  // Logout complet : appel API, vide le store, clear sessionStorage
  const logoutUser = useCallback(async () => {
    // 1. Invalider le cookie httpOnly côté serveur
    await api.auth.logout().catch(() => {})
    // 2. Vider le token JWT en mémoire
    setInMemoryToken(null)
    // 3. Déconnecter le socket
    disconnectSocket()
    // 4. Réinitialiser le store + vider sessionStorage
    try { sessionStorage.removeItem(SESSION_OB_KEY) } catch {}
    try { sessionStorage.removeItem('meereo_cached_user') } catch {}
    // 5. Reset store — IMPORTANT: _checking:false so the app doesn't show
    //    a permanent loading spinner (hydrationDone.current stays true,
    //    the boot useEffect won't re-run after a logout/delete)
    updateStore({ ...defaultStore, _hydrated: true, _checking: false })
  }, [updateStore])

  // ═══ SYNCHRONISATION COCKPIT / CLIENT ═══

  // Mettre à jour les étapes d'un projet (quand le pro avance le chantier)
  const updateProjectEtapes = useCallback((projectId, newEtapes, newPhase, newAvancement) => {
    updateStore(prev => {
      // Mettre à jour dans le store
      const projects = (prev.projects || []).map(p =>
        p.id === projectId ? { ...p, etapes: newEtapes, phase: newPhase, avancement: newAvancement } : p
      )
      return { ...prev, projects, lastProjectUpdate: { projectId, phase: newPhase, avancement: newAvancement, ts: Date.now() } }
    })
    emitEvent('project_phase_changed', { projectId, phase: newPhase, progress: newAvancement }, {
      notifMsg: `Projet avancé en phase ${newPhase} (${newAvancement}%)`,
      notifType: 'info'
    })
  }, [updateStore, emitEvent])

  // Sauvegarder l'état des tâches chantier dans le store (pour sync)
  const saveTaskStates = useCallback((projectId, taskStates) => {
    updateStore(prev => ({
      ...prev,
      taskStates: { ...(prev.taskStates || {}), [projectId]: taskStates }
    }))
  }, [updateStore])

  // Valider une tâche chantier (client ou architecte uniquement)
  const validateTask = useCallback((taskId, projectId, approved, comment) => {
    const role = getProjectRole(store.user?.id, projectId, store.projectMembers, store.user)
    if (!isAllowed(role, 'validate_task')) {
      showToast('Seul le maître d\'ouvrage ou l\'architecte peut valider une tâche', 'orange')
      return false
    }
    updateStore(prev => ({
      ...prev,
      tasks: (prev.tasks || []).map(t => t.id === taskId ? {
        ...t,
        validationStatus: approved ? 'validated' : 'rejected',
        validatedBy: prev.user?.id,
        validatedByRole: role,
        validatedAt: new Date().toISOString(),
        validationComment: comment || '',
      } : t)
    }))
    log(approved ? 'TASK_VALIDATED' : 'TASK_VALIDATION_REJECTED', { taskId, projectId, role })
    emitEvent(approved ? 'task_validated' : 'task_validation_rejected', { taskId, projectId }, {
      notifMsg: approved ? 'Tâche validée par ' + (role === ROLES.CLIENT ? clientLabel(storeRef.current).toLowerCase() : 'l\'architecte') : 'Tâche refusée — corrections requises',
      notifType: approved ? 'green' : 'orange',
    })
    return true
  }, [store.user, store.projectMembers, updateStore, log, emitEvent, showToast])

  // Créer une décision (côté pro/architecte, visible par le client)
  const createDecision = useCallback((data) => {
    // Guard: seuls PRO_ADMIN ou ARCHITECTE peuvent créer une décision
    const role = data.projectId
      ? getProjectRole(store.user?.id, data.projectId, store.projectMembers, store.user)
      : (store.user?.type === 'pro' ? ROLES.PRO_ADMIN : null)
    if (!isAllowed(role, 'create_decision')) {
      showToast('Vous n\'êtes pas autorisé à créer une décision', 'orange')
      return null
    }
    const decision = {
      id: 'dec_' + Date.now(),
      projectId: data.projectId || null,
      titre: data.titre || data.title || '',
      desc: data.desc || data.description || '',
      urgent: data.urgent || false,
      statut: 'en_attente',
      visibility: data.visibility || 'client_visible',
      // Source métier — lien vers l'objet déclencheur
      sourceType: data.sourceType || null,
      sourceId: data.sourceId || null,
      deadline: data.deadline || null,
      decisionType: data.decisionType || 'validation',
      // ═══ ACTEUR ═══
      createdBy: store.user?.id || null,
      createdByRole: role,
      createdByName: store.user?.name || '',
      targetRole: ROLES.CLIENT,
      createdAt: new Date().toISOString(),
    }
    updateStore(prev => ({ ...prev, decisions: [...(prev.decisions || []), decision] }))
    sync(api.decisions.create({ titre: decision.titre, description: decision.desc, statut: decision.statut, urgent: decision.urgent, visibility: decision.visibility, projectId: decision.projectId }))
    log('DECISION_CREATED', { title: decision.titre, projectId: decision.projectId, createdByRole: role })
    emitEvent('decision_created', { title: decision.titre, projectId: decision.projectId }, {
      notifMsg: `Décision requise : ${decision.titre}`,
      notifType: 'orange',
      toast: 'Décision envoyée'
    })
    return decision
  }, [store.user, store.projectMembers, updateStore, log, emitEvent, showToast])

  // Client valide/refuse une décision
  const respondDecision = useCallback((decisionId, response) => {
    // Guard: seul le client peut répondre à une décision
    if (!isAllowed(store.user?.type === 'client' ? ROLES.CLIENT : null, 'respond_decision')) {
      showToast('Seul le maître d\'ouvrage peut répondre à une décision', 'orange')
      return
    }
    // response = 'approved' | 'rejected' | 'info_requested'
    updateStore(prev => ({
      ...prev,
      decisions: (prev.decisions || []).map(d =>
        d.id === decisionId ? {
          ...d, statut: response,
          respondedBy: prev.user?.id || null,
          respondedByRole: ROLES.CLIENT,
          respondedAt: new Date().toISOString(),
        } : d
      )
    }))
    sync(api.decisions.update(decisionId, { statut: response }))
    const label = response === 'approved' ? 'validée' : response === 'rejected' ? 'refusée' : 'info demandée'
    log('DECISION_' + response.toUpperCase(), { decisionId, respondedByRole: ROLES.CLIENT })
    emitEvent('decision_' + response, { decisionId }, {
      notifMsg: `Décision ${label}`,
      notifType: response === 'approved' ? 'green' : 'orange',
      toast: `Décision ${label}`
    })
  }, [store.user, updateStore, log, emitEvent, showToast])

  // Demande de paiement (prestataire → client)
  const requestPayment = useCallback((data) => {
    // Guard: seuls les prestataires peuvent demander un paiement
    const role = data.projectId
      ? getProjectRole(store.user?.id, data.projectId, store.projectMembers, store.user)
      : null
    if (!isAllowed(role, 'request_payment') && store.user?.type !== 'pro') {
      showToast('Vous n\'êtes pas autorisé à demander un paiement', 'orange')
      return null
    }
    const req = {
      id: 'payreq_' + Date.now(),
      projectId: data.projectId,
      marketId: data.marketId || null,
      amount: data.amount || 0,
      label: data.label || 'Demande de paiement',
      paymentType: data.paymentType || 'paiement', // 'appel_de_fonds' | 'paiement' | 'acompte'
      statut: 'pending',
      visibility: 'client_visible',
      // ═══ ACTEURS ═══
      createdBy: store.user?.id || null,
      createdByRole: role,
      createdByName: store.user?.name || store.onboardingData?.entreprise || '',
      targetRole: ROLES.CLIENT, // Le client doit approuver
      createdAt: new Date().toISOString(),
    }
    updateStore(prev => ({
      ...prev,
      paymentRequests: [...(prev.paymentRequests || []), req]
    }))
    // Persister en base — remplacer le temp ID par le vrai ID retourné
    api.paymentRequests.create({
      projectId:     req.projectId,
      marketId:      req.marketId || null,
      amount:        req.amount,
      label:         req.label,
      paymentType:   req.paymentType,
      createdByName: req.createdByName,
      createdByRole: req.createdByRole,
      visibility:    req.visibility,
    }).then(saved => {
      if (saved?.id) {
        updateStore(prev => ({
          ...prev,
          paymentRequests: prev.paymentRequests.map(r => r.id === req.id ? { ...r, id: saved.id } : r),
        }))
      }
    }).catch(e => console.warn('[requestPayment]', e.message))
    log('PAYMENT_REQUESTED', { amount: req.amount, projectId: req.projectId, createdByRole: role, paymentType: req.paymentType })
    emitEvent('payment_requested', { amount: req.amount, projectId: req.projectId }, {
      notifMsg: `Demande de paiement : ${formatAmount(req.amount)}`,
      notifType: 'blue',
      toast: 'Demande de paiement envoyée'
    })
    return req
  }, [store.user, store.projectMembers, store.onboardingData, updateStore, log, emitEvent, showToast])

  // Client approuve/rejette un paiement
  const respondPayment = useCallback((requestId, response) => {
    updateStore(prev => {
      const req = (prev.paymentRequests || []).find(r => r.id === requestId)
      const updatedRequests = (prev.paymentRequests || []).map(r =>
        r.id === requestId ? {
          ...r, statut: response,
          respondedBy: prev.user?.id || null,
          respondedByRole: prev.user?.type === 'client' ? ROLES.CLIENT : null,
          respondedAt: new Date().toISOString(),
        } : r
      )
      // Si approuvé, créer automatiquement une transaction avec acteurs identifiés
      let newTx = prev.transactions || []
      if (response === 'approved' && req) {
        newTx = [...newTx, {
          id: 'tx_' + Date.now(),
          type: 'credit',
          paymentType: req.paymentType || 'paiement',
          label: req.label || 'Paiement client',
          montant: req.amount || 0,
          amount: req.amount || 0,
          date: new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }),
          provider: 'client',
          statut: 'confirmed',
          projet: req.projectId,
          projectId: req.projectId,
          marketId: req.marketId || null,
          paymentRequestId: req.id,
          // ═══ ACTEURS FINANCIERS ═══
          fromUserId: prev.user?.id || null,  // Le client qui paie
          fromRole: ROLES.CLIENT,
          toUserId: req.createdBy || null,     // Le prestataire qui reçoit
          toRole: req.createdByRole || null,
          approvedBy: prev.user?.id || null,
          visibility: 'client_visible',
          createdAt: new Date().toISOString(),
        }]
      }
      return { ...prev, paymentRequests: updatedRequests, transactions: newTx }
    })
    // Persister la réponse en base
    sync(api.paymentRequests.update(requestId, {
      statut:         response,
      respondedBy:    storeRef.current.user?.id || null,
      respondedByRole: storeRef.current.user?.type === 'client' ? 'client' : null,
      respondedAt:    new Date().toISOString(),
    }))
    const label = response === 'approved' ? 'approuvé' : 'refusé'
    log('PAYMENT_' + response.toUpperCase(), { requestId, respondedByRole: store.user?.type })
    emitEvent('payment_' + response, { requestId }, {
      notifMsg: `Paiement ${label}`,
      notifType: response === 'approved' ? 'green' : 'orange',
      toast: `Paiement ${label}`
    })
  }, [store.user, updateStore, log, emitEvent])

  // Nouvelle version d'un document
  const uploadNewVersion = useCallback(async (docId, file) => {
    try {
      const newDoc = await api.documents.uploadNewVersion(docId, file)
      updateStore(prev => ({
        ...prev,
        documents: [...prev.documents, { ...newDoc, nom: newDoc.name, isNew: true }],
      }))
      showToast('Nouvelle version ajoutée (v' + newDoc.version + ')', 'green')
      return newDoc
    } catch (e) {
      showToast(e.message || 'Erreur lors de la mise à jour', 'red')
      return null
    }
  }, [updateStore, showToast])

  // Partager un document avec le client
  const shareDocumentWithClient = useCallback((docId) => {
    updateStore(prev => ({
      ...prev,
      documents: (prev.documents || []).map(d =>
        d.id === docId ? { ...d, visibility: 'client_visible' } : d
      )
    }))
    emitEvent('document_shared_with_client', { docId }, {
      notifMsg: 'Document partagé',
      notifType: 'info'
    })
  }, [updateStore, emitEvent])

  // Ajouter une photo de chantier
  const addChantierPhoto = useCallback((data) => {
    const photo = {
      id: 'photo_' + Date.now(),
      projectId: data.projectId,
      url: data.url,
      caption: data.caption || '',
      date: new Date().toISOString(),
      visibility: data.visibility || 'client_visible',
    }
    updateStore(prev => ({
      ...prev,
      photos: [...(prev.photos || []), photo]
    }))
    sync(api.photos.create({ name: photo.caption || 'Photo', url: photo.url, projectId: photo.projectId || null }))
    if (photo.visibility === 'client_visible') {
      emitEvent('photo_added', { projectId: photo.projectId }, {
        notifMsg: 'Nouvelle photo de chantier ajoutée'
      })
    }
    return photo
  }, [updateStore, emitEvent])

  // ═══ FINTECH METHODS ═══
  const createPaymentOrder = useCallback((data) => {
    const order = {
      id: 'po_' + Date.now(),
      type: data.type || 'marche',
      projectId: data.projectId || null,
      marketId: data.marketId || null,
      orderId: data.orderId || null,
      milestoneId: data.milestoneId || null,
      payerId: data.payerId || store.user?.id || null,
      beneficiaryId: data.beneficiaryId || null,
      railRecommended: data.railRecommended || 'carte',
      railUsed: data.railUsed || null,
      amountGross: data.amount || 0,
      currency: 'XOF',
      pspFeesEstimated: Math.round((data.amount || 0) * 0.015),
      meereoCommission: data.commission || 0,
      status: 'PAY_INIT',
      createdAt: new Date().toISOString(),
    }
    updateStore(prev => ({
      ...prev,
      paymentOrders: [...(prev.paymentOrders || []), order],
      ledgerEntries: [...(prev.ledgerEntries || []), {
        id: 'le_' + Date.now(),
        paymentOrderId: order.id,
        entryType: 'credit',
        amount: order.amountGross,
        createdAt: order.createdAt,
        description: 'Ordre de paiement créé — ' + (data.label || order.type),
      }],
    }))
    addNotif('Ordre de paiement créé — ' + (data.label || order.amountGross.toLocaleString() + ' FCFA'), 'blue', null, 'finance')
    return order
  }, [store.user, updateStore, addNotif])

  const updatePaymentStatus = useCallback((orderId, newStatus, meta = {}) => {
    updateStore(prev => {
      const order = (prev.paymentOrders || []).find(o => o.id === orderId)
      if (!order) return prev
      const now = new Date().toISOString()
      const updatedOrders = (prev.paymentOrders || []).map(o =>
        o.id === orderId ? { ...o, status: newStatus, ...(newStatus === 'FUNDS_CONFIRMED' ? { confirmedAt: now, amountConfirmed: o.amountGross } : {}), ...(newStatus === 'PAYOUT_DONE' ? { payoutDoneAt: now, amountReleased: o.amountGross - o.meereoCommission } : {}), ...(newStatus === 'DISPUTE_OPEN' ? { disputeReason: meta.reason || '' } : {}), ...meta } : o
      )
      const newEntry = {
        id: 'le_' + Date.now(),
        paymentOrderId: orderId,
        entryType: newStatus === 'REVERSED' ? 'reverse' : newStatus === 'PAYOUT_DONE' ? 'release' : newStatus === 'HELD_FOR_MILESTONE' ? 'hold' : newStatus === 'DISPUTE_OPEN' ? 'hold' : 'credit',
        amount: order.amountGross,
        createdAt: now,
        description: 'Statut → ' + newStatus,
      }
      // Auto-generate commission on PAYOUT_DONE
      let newCommissions = prev.commissions || []
      if (newStatus === 'PAYOUT_DONE' && order.meereoCommission > 0) {
        const commType = order.type === 'commande' ? 'marketplace' : order.type === 'marche' ? 'services' : 'orchestration'
        newCommissions = [...newCommissions, {
          id: 'com_' + Date.now(),
          type: commType,
          linkedObjectId: orderId,
          linkedObjectType: order.type,
          rate: commType === 'marketplace' ? 0.08 : commType === 'services' ? 0.05 : 0.01,
          baseAmount: order.amountGross,
          commissionAmount: order.meereoCommission,
          status: 'calculated',
          createdAt: now,
        }]
      }
      return { ...prev, paymentOrders: updatedOrders, ledgerEntries: [...(prev.ledgerEntries || []), newEntry], commissions: newCommissions }
    })
  }, [updateStore])

  const openDispute = useCallback((orderId, reason) => {
    const now = new Date().toISOString()
    updateStore(prev => {
      const dispute = {
        id: 'disp_' + Date.now(),
        paymentOrderId: orderId,
        openedBy: prev.user?.id || 'unknown',
        reason: reason || 'Contestation',
        status: 'open',
        createdAt: now,
        impactedPayouts: (prev.paymentOrders || []).filter(o => o.status === 'PAYOUT_REQUESTED' && o.projectId === ((prev.paymentOrders || []).find(x => x.id === orderId)?.projectId)).map(o => o.id),
      }
      const updatedOrders = (prev.paymentOrders || []).map(o =>
        o.id === orderId ? { ...o, status: 'DISPUTE_OPEN', disputeReason: reason } : o
      )
      return { ...prev, disputeCases: [...(prev.disputeCases || []), dispute], paymentOrders: updatedOrders }
    })
    addNotif('Litige ouvert — libérations gelées', 'orange', null, 'finance')
  }, [updateStore, addNotif])

  const resolveDispute = useCallback((disputeId, resolution, inFavorOf) => {
    updateStore(prev => {
      const dispute = (prev.disputeCases || []).find(d => d.id === disputeId)
      if (!dispute) return prev
      const newStatus = inFavorOf === 'beneficiary' ? 'PAYOUT_DONE' : 'REVERSED'
      const updatedDisputes = (prev.disputeCases || []).map(d =>
        d.id === disputeId ? { ...d, status: 'resolved', resolution, resolvedAt: new Date().toISOString() } : d
      )
      const updatedOrders = (prev.paymentOrders || []).map(o =>
        o.id === dispute.paymentOrderId ? { ...o, status: newStatus } : o
      )
      return { ...prev, disputeCases: updatedDisputes, paymentOrders: updatedOrders }
    })
    addNotif('Litige résolu — ' + (inFavorOf === 'beneficiary' ? 'fonds libérés' : 'fonds remboursés'), 'green', null, 'finance')
  }, [updateStore, addNotif])

  const uploadProof = useCallback((data) => {
    const proof = {
      id: 'proof_' + Date.now(),
      payoutRequestId: data.payoutRequestId || data.paymentOrderId,
      type: data.type || 'autre',
      fileUrl: data.fileUrl || data.url || '',
      uploadedBy: store.user?.id || 'unknown',
      uploadedAt: new Date().toISOString(),
      verified: false,
    }
    updateStore(prev => ({ ...prev, proofDocuments: [...(prev.proofDocuments || []), proof] }))
    return proof
  }, [store.user, updateStore])

  const trackKaiUsage = useCallback((action, role = 'pro') => {
    const period = new Date().toISOString().slice(0, 7)
    updateStore(prev => {
      const allEnt = prev.kaiEntitlement || {}
      const ent = allEnt[role] || { tier: 'standard', quotaLimit: 25, quotaUsed: 0 }
      const isGold = ent.tier === 'gold' && ent.goldEndDate && new Date(ent.goldEndDate) > new Date()
      const newUsed = isGold ? ent.quotaUsed : (ent.quotaUsed || 0) + 1
      return {
        ...prev,
        kaiUsage: [...(prev.kaiUsage || []), { id: 'ku_' + Date.now(), userId: prev.user?.id, action, role, tier: isGold ? 'gold' : 'standard', createdAt: new Date().toISOString(), quotaPeriod: period }],
        kaiEntitlement: { ...allEnt, [role]: { ...ent, quotaUsed: newUsed } },
      }
    })
  }, [updateStore])

  const upgradeToGold = useCallback((role) => {
    const activeRole = role || store.user?.type || 'pro'
    const now = new Date()
    const end = new Date(now)
    end.setMonth(end.getMonth() + 1)
    const goldData = {
      tier: 'gold',
      goldStartDate: now.toISOString(),
      goldEndDate: end.toISOString(),
    }
    // Persister côté serveur
    api.kai.updateEntitlement(activeRole, goldData).catch(() => {})
    // Optimistic update
    updateStore(prev => {
      const allEnt = prev.kaiEntitlement || {}
      return {
        ...prev,
        kaiEntitlement: {
          ...allEnt,
          [activeRole]: { ...(allEnt[activeRole] || { quotaLimit: 25, quotaUsed: 0 }), ...goldData },
        },
      }
    })
    const labels = { pro: 'Professionnel', client: 'Client', fournisseur: 'Fournisseur' }
    addNotif('KAi Pro activé — Espace ' + (labels[activeRole] || activeRole), 'green', null, 'parametres')
    showToast('KAi Pro activé', 'green')
  }, [store.user, updateStore, addNotif, showToast])

  // ═══ COMMISSION WORKFLOW (clé en main uniquement) ═══
  const { isCleEnMain: _isCEM, calculateCommission: _calcComm, INTRO_STATUS: _IS, COMMISSION_STATUS: _CS } = (() => {
    try { return require('../domain/commission') } catch { return {} }
  })()

  // Créer une introduction (mise en relation MEEREO → structure)
  const createIntroduction = useCallback((data) => {
    // Guard: uniquement en mode clé en main
    if (!_isCEM || !_isCEM(storeRef.current)) return null
    const intro = {
      id: 'intro_' + Date.now(),
      projectId: data.projectId || null,
      clientId: data.clientId || storeRef.current.user?.id || null,
      structureId: data.structureId || null,
      structureName: data.structureName || '',
      metier: data.metier || '',
      status: _IS?.INTRODUCED || 'introduced',
      introDate: new Date().toISOString(),
      retainedAt: null,
      source: 'meereo_cle_en_main',
    }
    updateStore(prev => ({ ...prev, introductions: [...(prev.introductions || []), intro] }))
    log('INTRO_CREATED', { structureName: intro.structureName, projectId: intro.projectId })
    return intro
  }, [updateStore, log])

  // Retenir une structure → déclenche la commission
  const retainStructure = useCallback((introductionId, montantBase) => {
    if (!_isCEM || !_isCEM(storeRef.current)) return null
    let commission = null
    updateStore(prev => {
      const intro = (prev.introductions || []).find(i => i.id === introductionId)
      if (!intro) return prev
      const calc = _calcComm ? _calcComm(montantBase) : { base: montantBase || 0, rate: 0.05, amount: Math.round((montantBase || 0) * 0.05) }
      commission = {
        id: 'comm_' + Date.now(),
        introductionId,
        structureId: intro.structureId,
        structureName: intro.structureName,
        projectId: intro.projectId,
        clientId: intro.clientId,
        montantBase: calc.base,
        montantCommission: calc.amount,
        rate: calc.rate,
        status: _CS?.DUE || 'due',
        createdAt: new Date().toISOString(),
        paidAt: null,
      }
      return {
        ...prev,
        introductions: (prev.introductions || []).map(i => i.id === introductionId ? { ...i, status: _IS?.RETAINED || 'retained', retainedAt: new Date().toISOString() } : i),
        commissions: [...(prev.commissions || []), commission],
      }
    })
    if (commission) {
      log('COMMISSION_CREATED', { structureName: commission.structureName, amount: commission.montantCommission })
      addNotif('Commission MEEREO : ' + (commission.montantCommission || 0).toLocaleString('fr-FR') + ' FCFA', 'blue', null, 'parametres')
    }
    return commission
  }, [updateStore, log, addNotif])

  // Mettre à jour le statut d'une commission
  const updateCommissionStatus = useCallback((commissionId, newStatus) => {
    updateStore(prev => ({
      ...prev,
      commissions: (prev.commissions || []).map(c => c.id === commissionId ? { ...c, status: newStatus, ...(newStatus === 'paid' ? { paidAt: new Date().toISOString() } : {}) } : c),
    }))
    log('COMMISSION_STATUS_CHANGED', { commissionId, newStatus })
  }, [updateStore, log])

  // Accepter les CGV commission (côté pro)
  const acceptCommissionTerms = useCallback(() => {
    const userId = storeRef.current.user?.id
    if (!userId) return
    const updated = [...(storeRef.current.commissionAcceptances || []), { userId, acceptedAt: new Date().toISOString() }]
    updateStore(prev => ({
      ...prev,
      commissionAcceptances: updated,
    }))
    // Persister en DB dans les préférences utilisateur
    api.usersApi.updatePrefs({ commissionAcceptances: updated }).catch(() => {})
    log('COMMISSION_TERMS_ACCEPTED', { userId })
    showToast('Conditions de mise en relation acceptées', 'green')
  }, [updateStore, log, showToast])

  // Vérifier si un pro a accepté les CGV
  const hasAcceptedCommissionTerms = useCallback((userId) => {
    return (storeRef.current.commissionAcceptances || []).some(a => a.userId === (userId || storeRef.current.user?.id))
  }, [])

  const value = {
    store,
    updateStore,
    toasts,
    showToast,
    notifOpen,
    setNotifOpen,
    log,
    addNotif,
    markNotifRead,
    markNotifsRead,
    createUser,
    loginUser,
    createOrganization,
    addMemberToOrg,
    createProject,
    deleteProject,
    hardDeleteProject,
    stopProject,
    archiveProject,
    unarchiveProject,
    updateProject,
    inviteClientToProject,
    respondProjectInvitation,
    requestCloture,
    respondCloture,
    createMission,
    updateMission,
    deleteMission,
    updateMissionJalons,
    createAO,
    submitOffer,
    acceptOffer,
    rejectOffer,
    triggerPayment,
    confirmPayment,
    uploadDocument,
    addProduct,
    updateMarketProgress,
    resetStore,
    // Sync methods
    emitEvent,
    updateProjectEtapes,
    saveTaskStates,
    createDecision,
    respondDecision,
    requestPayment,
    respondPayment,
    shareDocumentWithClient,
    addChantierPhoto,
    uploadNewVersion,
    createAsset,
    updateAsset,
    addMaintenance,
    generatePassport,
    // Fintech
    createPaymentOrder,
    updatePaymentStatus,
    openDispute,
    resolveDispute,
    uploadProof,
    trackKaiUsage,
    upgradeToGold,
    sendAOInvitation,
    deleteAO,
    updateAO,
    archiveAO,
    // Multi-acteurs V2
    addProjectMember,
    removeProjectMember,
    getProjectMembers,
    validateTask,
    // Commission workflow (clé en main)
    createIntroduction,
    retainStructure,
    updateCommissionStatus,
    acceptCommissionTerms,
    hasAcceptedCommissionTerms,
    logoutUser,
  }

  return <MeereoContext.Provider value={value}>{children}</MeereoContext.Provider>
}

export function useMeereo() {
  const ctx = useContext(MeereoContext)
  if (!ctx) throw new Error('useMeereo must be used within MeereoProvider')
  return ctx
}

export function formatAmount(val) {
  if (!val) return '0 FCFA'
  const n = parseFloat(val)
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'Mds FCFA'
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M FCFA'
  if (n >= 1e3) return (n / 1e3).toFixed(0) + 'K FCFA'
  return n.toLocaleString('fr-FR') + ' FCFA'
}

export function formatDate(iso) {
  if (!iso) return '\u2014'
  try {
    const d = new Date(iso)
    return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
  } catch (e) { return iso }
}

export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
}
