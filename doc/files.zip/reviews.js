const { Router } = require('express')
const { getPrisma } = require('../db')
const { requireAuth } = require('../middleware/auth')
const { createError } = require('../middleware/errorHandler')

const router = Router()

// GET /api/reviews?targetId=xxx — avis reçus par un professionnel
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const { targetId } = req.query
    if (!targetId) throw createError('targetId requis', 400)

    const reviews = await prisma.review.findMany({
      where: { targetId },
      include: { author: { select: { id: true, name: true, company: true } } },
      orderBy: { createdAt: 'desc' },
    })
    res.json(reviews)
  } catch (e) { next(e) }
})

// POST /api/reviews — créer un avis (client uniquement, après projet)
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const { targetId, projectId, note, qualite, delais, communication, comment } = req.body
    if (!targetId) throw createError('targetId requis', 400)
    if (!note || note < 1 || note > 5) throw createError('Note entre 1 et 5 requise', 400)

    // AVS-07 : vérifier EN BASE l'entité qui reçoit l'avis.
    // 1. Jamais soi-même (le modal a déjà présenté le client à la place de
    //    l'entreprise titulaire — ce garde-fou rend l'erreur impossible en base).
    if (targetId === req.user.id) throw createError("Vous ne pouvez pas vous évaluer vous-même", 400)
    // 2. Le destinataire d'une évaluation de fin de projet est une ENTREPRISE
    //    (professionnel ou intervenant), jamais un compte client.
    const target = await prisma.user.findUnique({ where: { id: targetId }, select: { id: true, type: true } })
    if (!target) throw createError('Destinataire introuvable', 404)
    if (target.type === 'client') throw createError("Un avis de fin de projet s'adresse à l'entreprise titulaire, pas à un client", 400)

    // Vérifier que l'auteur a collaboré avec la cible sur un projet
    const hasCollaboration = await prisma.projectMember.findFirst({
      where: {
        userId: targetId,
        project: { OR: [{ ownerId: req.user.id }, { clientId: req.user.id }] },
      },
    })
    if (!hasCollaboration) throw createError('Vous devez avoir collaboré avec ce professionnel pour laisser un avis', 403)

    // Vérifier que le projet est en statut completed ou cloture (si projectId fourni)
    if (projectId) {
      const project = await prisma.project.findUnique({ where: { id: projectId }, select: { status: true } })
      if (project && !['completed', 'cloture'].includes(project.status)) {
        throw createError('Les avis ne peuvent être déposés que sur un projet terminé ou clôturé', 400)
      }
    }

    // AVS-01: évaluation croisée — client→pro ET pro→intervenant
    // Un pro peut évaluer un autre pro/intervenant avec qui il a travaillé sur un projet
    if (req.user.type === 'pro') {
      const sharedProjectAsPro = await prisma.projectMember.findFirst({
        where: {
          userId: targetId,
          project: { ownerId: req.user.id },
        },
      })
      if (!sharedProjectAsPro) {
        throw createError('Vous ne pouvez évaluer que les intervenants de vos projets', 403)
      }
    }

    const review = await prisma.review.upsert({
      where: { authorId_targetId_projectId: { authorId: req.user.id, targetId, projectId: projectId || '' } },
      update: { note, qualite: qualite || null, delais: delais || null, communication: communication || null, comment: comment || '' },
      create: {
        authorId: req.user.id,
        targetId,
        projectId: projectId || null,
        note,
        qualite: qualite || null,
        delais: delais || null,
        communication: communication || null,
        comment: comment || '',
      },
    })
    res.status(201).json(review)
  } catch (e) { next(e) }
})

module.exports = router
