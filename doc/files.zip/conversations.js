const { Router } = require('express')
const { requireAuth } = require('../middleware/auth')
const { getPrisma } = require('../db')
const { getIo } = require('../socket')

const router = Router()

// ─── Shared participant user select (includes profile tables for photo lookup) ─
const PARTICIPANT_USER_SELECT = {
  select: {
    id: true, name: true, email: true, type: true, publicId: true, avatar: true, onboardingData: true,
    proProfile:         { select: { logoFileUrl: true } },
    clientProfile:      { select: { photoUrl: true } },
    fournisseurProfile: { select: { logoFileUrl: true } },
  },
}

// Strip base64 — only keep real URLs
const safeUrl = (v) => (v && typeof v === 'string' && !v.startsWith('data:') ? v : null)

// Compute a canonical photoUrl for a participant and remove the raw profile sub-objects
const mapParticipantUser = (u) => {
  if (!u) return u
  const photoUrl =
    safeUrl(u.proProfile?.logoFileUrl) ||
    safeUrl(u.clientProfile?.photoUrl) ||
    safeUrl(u.fournisseurProfile?.logoFileUrl) ||
    safeUrl(u.onboardingData?.logoFileUrl) ||
    safeUrl(u.onboardingData?.photoUrl) ||
    safeUrl(u.avatar) ||
    null
  const { proProfile: _1, clientProfile: _2, fournisseurProfile: _3, ...rest } = u
  return { ...rest, photoUrl }
}

// ─── Lister les conversations de l'utilisateur connecté ──────────────────────────────
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const userId = req.user.id

    const page = Math.max(1, parseInt(req.query.page) || 1)
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 50))
    const skip = (page - 1) * limit

    const participations = await prisma.conversationParticipant.findMany({
      where: { userId },
      include: {
        conversation: {
          include: {
            participants: {
              include: { user: PARTICIPANT_USER_SELECT },
            },
            messages: {
              orderBy: { createdAt: 'desc' },
              take: 1,
              include: { sender: { select: { id: true, name: true } } },
            },
          },
        },
      },
      orderBy: { conversation: { updatedAt: 'desc' } },
      take: limit,
      skip,
    })

    // Vérifier le type de l'utilisateur pour filtrage sécurité
    const currentUser = await prisma.user.findUnique({ where: { id: userId }, select: { type: true } })
    const isPro = currentUser?.type === 'pro'

    // Pro visibility: allow all conversations where the pro is a participant
    // (removed project-based client filter — clients can contact pros freely via public pages)
    let allowedClientIds = null

    // Compute unread counts in a single batch query (not N+1)
    const convIds = participations.map(p => p.conversationId)
    const unreadCounts = {}
    if (convIds.length > 0) {
      const counts = await Promise.all(participations.map(p => {
        const where = { conversationId: p.conversationId, senderId: { not: userId } }
        if (p.lastReadAt) where.createdAt = { gt: p.lastReadAt }
        return prisma.message.count({ where }).then(n => ({ convId: p.conversationId, count: n }))
      }))
      counts.forEach(({ convId, count }) => { unreadCounts[convId] = count })
    }

    // MSG-04: résoudre le nom des projets liés (libellé contextuel côté client/pro)
    const projectIds = [...new Set(participations.map(p => p.conversation.projectId).filter(Boolean))]
    const projectNames = {}
    if (projectIds.length > 0) {
      const projects = await prisma.project.findMany({ where: { id: { in: projectIds } }, select: { id: true, nom: true } })
      projects.forEach(pr => { projectNames[pr.id] = pr.nom })
    }

    let conversations = participations.map((p) => {
      const c = p.conversation
      const lastMsg = c.messages[0] || null
      const lastReadAt = p.lastReadAt
      return {
        id: c.id,
        title: c.title,
        isGroup: c.isGroup,
        type: c.type,
        aoId: c.aoId,
        offerId: c.offerId,
        projectId: c.projectId,
        missionId: c.missionId,
        projectName: c.projectId ? (projectNames[c.projectId] || null) : null,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
        participants: c.participants.map((pp) => mapParticipantUser(pp.user)),
        lastMessage: lastMsg
          ? { id: lastMsg.id, text: lastMsg.text, type: lastMsg.type, senderId: lastMsg.senderId, senderName: lastMsg.sender.name, createdAt: lastMsg.createdAt }
          : null,
        lastReadAt: lastReadAt,
        unread: unreadCounts[c.id] || 0,
      }
    })

    // Sécurité : un pro ne voit que les conversations avec des clients liés à ses projets
    if (isPro && allowedClientIds) {
      conversations = conversations.filter(c => {
        if (c.isGroup) return true // Les groupes restent visibles
        // Pour les 1:1, vérifier que l'autre participant n'est pas un client non-autorisé
        const otherParticipants = c.participants.filter(pp => pp.id !== userId)
        return otherParticipants.every(pp => pp.type !== 'client' || allowedClientIds.has(pp.id))
      })
    }

    res.json(conversations)
  } catch (err) {
    next(err)
  }
})

// ─── Créer ou retrouver une conversation 1:1 ─────────────────────────────────
// POST /api/conversations
// Body: { participantId } pour 1:1 ou { participantIds[], title } pour groupe
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const myId = req.user.id
    const { participantId, participantIds, title, aoId, offerId, type, projectId, missionId } = req.body

    if (participantId) {
      // MSG-01 cas 3: si le destinataire n'existe pas (entreprise référencée sans compte),
      // persister le message en attente et signaler qu'une invitation sera envoyée
      const recipientExists = await prisma.user.findUnique({ where: { id: participantId }, select: { id: true, email: true, deletedAt: true } })
      if (!recipientExists || recipientExists.deletedAt) {
        // Le participantId n'est pas un utilisateur actif — persister le message en attente
        const { message: msgText, recipientEmail, recipientPhone, recipientRef } = req.body
        await prisma.pendingMessage.create({
          data: {
            senderId: myId,
            recipientEmail: recipientEmail || null,
            recipientPhone: recipientPhone || null,
            recipientRef: participantId,
            text: msgText || 'Bonjour, je souhaiterais échanger avec vous.',
            type: 'text',
          },
        }).catch(() => {})

        // TODO: envoyer email/SMS d'invitation si recipientEmail/recipientPhone disponible
        // « Un client vous a contacté sur MEEREO, inscrivez-vous pour lire son message »

        return res.status(202).json({
          pending: true,
          message: 'Ce professionnel n\'est pas encore inscrit sur MEEREO. Votre message sera conservé et lui sera transmis dès son inscription.',
        })
      }

      // ─── Sécurité : un pro ne peut contacter un client que s'ils partagent un projet ───
      const me = await prisma.user.findUnique({ where: { id: myId }, select: { type: true } })
      const other = await prisma.user.findUnique({ where: { id: participantId }, select: { type: true } })
      if (me?.type === 'pro' && other?.type === 'client') {
        const sharedProject = await prisma.project.findFirst({
          where: {
            OR: [
              { ownerId: myId, clientId: participantId },
              { ownerId: participantId, clientId: myId },
              { AND: [
                { members: { some: { userId: myId } } },
                { OR: [{ clientId: participantId }, { ownerId: participantId }] },
              ]},
              { AND: [
                { members: { some: { userId: participantId } } },
                { OR: [{ clientId: myId }, { ownerId: myId }] },
              ]},
            ],
          },
        })
        if (!sharedProject) {
          return res.status(403).json({ error: 'Vous ne pouvez contacter ce client que si vous partagez un projet' })
        }
      }
      // MSG-02: un fournisseur ne peut contacter que les acheteurs ayant une commande avec lui
      if (me?.type === 'fournisseur') {
        const sharedOrder = await prisma.order.findFirst({
          where: {
            OR: [
              { sellerId: myId, buyerId: participantId },
              { buyerId: myId, sellerId: participantId },
            ],
          },
        })
        if (!sharedOrder) {
          return res.status(403).json({ error: 'Vous ne pouvez contacter que les acheteurs ayant une commande avec vous' })
        }
      }

      // ─── MSG-04: 1:1 — conversation UNIQUE par binôme, garantie par pairHash ──
      // pairHash = IDs triés et joints, garantit l'unicité en DB (@unique sur pairHash)
      const pairHash = [myId, participantId].sort().join('::')

      // Chercher la conversation existante via pairHash (rapide, indexé)
      const existing = await prisma.conversation.findUnique({
        where: { pairHash },
        include: {
          participants: {
            include: { user: PARTICIPANT_USER_SELECT },
          },
          messages: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
      })

      if (existing) {
        if (existing.participants) existing.participants = existing.participants.map(pp => ({ ...pp, user: mapParticipantUser(pp.user) }))
        // MSG-04: rattacher le contexte métier à la conversation existante si fourni
        if ((projectId || aoId || offerId || missionId) && !existing.projectId) {
          await prisma.conversation.update({
            where: { id: existing.id },
            data: {
              ...(projectId && !existing.projectId ? { projectId } : {}),
              ...(aoId && !existing.aoId ? { aoId } : {}),
              ...(offerId && !existing.offerId ? { offerId } : {}),
              ...(missionId && !existing.missionId ? { missionId } : {}),
            },
          }).catch(() => {})
        }
        return res.json({ conversation: existing, created: false })
      }

      // Créer la conversation avec pairHash — la contrainte @unique empêche les doublons
      let conv
      try {
        conv = await prisma.conversation.create({
          data: {
            isGroup: false,
            pairHash,
            type: type || 'libre',
            aoId: aoId || null,
            offerId: offerId || null,
            projectId: projectId || null,
            missionId: missionId || null,
            participants: {
              create: [
                { userId: myId },
                { userId: participantId },
              ],
            },
          },
          include: {
            participants: {
              include: { user: PARTICIPANT_USER_SELECT },
            },
            messages: true,
          },
        })
      } catch (e) {
        // Race condition: pairHash unique violation — retourner la conversation existante
        if (e.code === 'P2002') {
          const race = await prisma.conversation.findUnique({
            where: { pairHash },
            include: {
              participants: { include: { user: PARTICIPANT_USER_SELECT } },
              messages: { orderBy: { createdAt: 'desc' }, take: 1 },
            },
          })
          if (race) return res.json({ conversation: race, created: false })
        }
        throw e
      }

      // Notifier l'autre participant via socket
      const io = getIo()
      if (io) {
        io.to(`user:${participantId}`).emit('conversation:updated', {
          conversationId: conv.id,
          lastMessage: null,
        })
      }
      return res.status(201).json({ conversation: conv, created: true })
    }

    if (participantIds && Array.isArray(participantIds)) {
      // ─── Groupe ───────────────────────────────────────────────────────────
      const allIds = [...new Set([myId, ...participantIds.filter(Boolean)])]
      // MSG-08 : garde-fou d'IDEMPOTENCE — une seule conversation de groupe par
      // projet (ou par mission), quel que soit le nombre de fois où l'événement
      // de lancement est déclenché. Même principe que le pairHash de MSG-04.
      if (projectId || missionId) {
        const existingGroup = await prisma.conversation.findFirst({
          where: {
            isGroup: true,
            ...(projectId ? { projectId } : { missionId }),
          },
          include: {
            participants: { include: { user: PARTICIPANT_USER_SELECT } },
            messages: true,
          },
        })
        if (existingGroup) {
          // Rattacher les participants manquants au groupe existant plutôt
          // que d'en créer un second (MSG-07 : extension, pas duplication).
          const existingIds = new Set(existingGroup.participants.map(p => p.userId))
          const missing = allIds.filter(uid => !existingIds.has(uid))
          if (missing.length > 0) {
            await prisma.conversationParticipant.createMany({
              data: missing.map(uid => ({ conversationId: existingGroup.id, userId: uid })),
              skipDuplicates: true,
            })
          }
          return res.status(200).json({ conversation: existingGroup, created: false })
        }
      }
      console.log('[conversations] Creating group — myId:', myId, '| participantIds:', participantIds, '| allIds:', allIds)
      const conv = await prisma.conversation.create({
        data: {
          isGroup: true,
          title: title || 'Groupe',
          type: type || 'libre',
          aoId: aoId || null,
          offerId: offerId || null,
          projectId: projectId || null,
          missionId: missionId || null,
          participants: {
            create: allIds.map((uid) => ({ userId: uid })),
          },
        },
        include: {
          participants: {
            include: { user: PARTICIPANT_USER_SELECT },
          },
          messages: true,
        },
      })
      // Notifier tous les autres participants via socket pour qu'ils voient la conversation immédiatement
      const io = getIo()
      if (io) {
        allIds.filter(uid => uid !== myId).forEach(uid => {
          io.to(`user:${uid}`).emit('conversation:updated', {
            conversationId: conv.id,
            lastMessage: null,
          })
        })
      }
      return res.status(201).json({ conversation: conv, created: true })
    }

    return res.status(400).json({ error: 'participantId ou participantIds requis' })
  } catch (err) {
    next(err)
  }
})

// ─── Récupérer les messages d'une conversation (paginés) ─────────────────────
router.get('/:id/messages', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const userId = req.user.id
    const { id } = req.params
    const cursor = req.query.cursor // id du dernier message connu (pagination)
    const limit = Math.min(parseInt(req.query.limit || '50', 10), 100)

    // Vérifier que l'utilisateur est bien participant
    const participation = await prisma.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId } },
    })
    if (!participation) return res.status(403).json({ error: 'Accès refusé' })

    // MSG-07 G4: filtrer les messages postérieurs à la date d'ajout du participant
    // Un participant ajouté ne voit que les messages postérieurs à son ajout
    const joinedAt = participation.createdAt
    const messages = await prisma.message.findMany({
      where: {
        conversationId: id,
        createdAt: { gte: joinedAt },
        ...(cursor ? { createdAt: { lt: (await prisma.message.findUnique({ where: { id: cursor } }))?.createdAt, gte: joinedAt } } : {}),
      },
      orderBy: { createdAt: 'asc' },
      take: limit,
      include: { sender: { select: { id: true, name: true, type: true } } },
    })

    res.json({ messages })
  } catch (err) {
    next(err)
  }
})
// ─── Envoyer un message dans une conversation (fallback HTTP — socket en priorité) ─────────
router.post('/:id/messages', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const userId = req.user.id
    const { id } = req.params
    const { text, type, fileUrl, fileName } = req.body

    if (!text && !fileUrl) return res.status(400).json({ error: 'text ou fileUrl requis' })

    // Vérifier participation
    const participation = await prisma.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId } },
    })
    if (!participation) return res.status(403).json({ error: 'Accès refusé' })

    const message = await prisma.message.create({
      data: {
        conversationId: id,
        senderId: userId,
        text: text || '',
        type: type || 'text',
        fileUrl: fileUrl || null,
        fileName: fileName || null,
      },
      include: { sender: { select: { id: true, name: true, type: true } } },
    })

    // Mettre à jour updatedAt de la conversation
    await prisma.conversation.update({
      where: { id },
      data: { updatedAt: new Date() },
    })

    // Notifier les autres participants via socket (temps réel)
    const io = getIo()
    if (io) {
      const participants = await prisma.conversationParticipant.findMany({
        where: { conversationId: id },
        select: { userId: true },
      })
      const lastMsgPayload = { id: message.id, text: message.text, type: message.type, senderId: message.senderId, senderName: message.sender.name, createdAt: message.createdAt }
      participants.filter(p => p.userId !== userId).forEach(p => {
        io.to(`user:${p.userId}`).emit('conversation:updated', { conversationId: id, lastMessage: lastMsgPayload })
        io.to(`user:${p.userId}`).emit('notification:new', {
          id: 'notif_msg_' + message.id,
          msg: `Nouveau message de ${message.sender.name}`,
          type: 'info',
          read: false,
          ts: message.createdAt,
        })
      })
      // Émettre aussi dans la room de la conversation
      io.to(`conv:${id}`).emit('message:new', message)
    }

    res.status(201).json(message)
  } catch (err) {
    next(err)
  }
})
// ─── Marquer une conversation comme lue ──────────────────────────────────────
router.patch('/:id/read', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const userId = req.user.id
    const { id } = req.params
    await prisma.conversationParticipant.updateMany({
      where: { conversationId: id, userId },
      data: { lastReadAt: new Date() },
    })
    res.json({ ok: true })
  } catch (err) {
    next(err)
  }
})

// ─── Ajouter un participant à une conversation existante ─────────────────────
// POST /api/conversations/:id/participants  { userId }
router.post('/:id/participants', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const myId = req.user.id
    const { id } = req.params
    const { userId } = req.body
    if (!userId) return res.status(400).json({ error: 'userId requis' })

    // Vérifier que l'appelant est participant
    const myPart = await prisma.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: myId } },
    })
    if (!myPart) return res.status(403).json({ error: 'Accès refusé' })

    // MSG-07 G3: seul le professionnel responsable du marché peut ajouter des intervenants
    const conv = await prisma.conversation.findUnique({ where: { id }, select: { projectId: true } })
    if (conv?.projectId) {
      const project = await prisma.project.findUnique({
        where: { id: conv.projectId },
        select: { ownerId: true },
      })
      if (project && project.ownerId !== myId && req.user.type !== 'admin') {
        return res.status(403).json({ error: 'Seul le professionnel responsable du projet peut ajouter des participants' })
      }
    }

    // Vérifier que l'utilisateur cible existe
    const targetUser = await prisma.user.findUnique({ where: { id: userId } })
    if (!targetUser) return res.status(404).json({ error: 'Utilisateur introuvable' })

    // Ajouter le participant (ignorer si déjà présent)
    try {
      await prisma.conversationParticipant.create({
        data: { conversationId: id, userId },
      })
    } catch (e) {
      if (e.code === 'P2002') return res.json({ ok: true, alreadyMember: true })
      throw e
    }

    // Marquer la conversation comme groupe si elle ne l'est pas déjà
    await prisma.conversation.update({
      where: { id },
      data: { isGroup: true, updatedAt: new Date() },
    })

    // Retourner la conversation mise à jour
    const updatedConv = await prisma.conversation.findUnique({
      where: { id },
      include: {
        participants: { include: { user: PARTICIPANT_USER_SELECT } },
        messages: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    })
    if (updatedConv?.participants) updatedConv.participants = updatedConv.participants.map(pp => ({ ...pp, user: mapParticipantUser(pp.user) }))
    res.json({ ok: true, conversation: updatedConv })
  } catch (err) {
    next(err)
  }
})

// ─── MSG-07: Retirer un participant d'une conversation ──────────────────────
// DELETE /conversations/:id/participants/:userId
// Seul le pro responsable du projet peut retirer (G3).
router.delete('/:id/participants/:userId', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const myId = req.user.id
    const { id, userId } = req.params

    // Vérifier que l'appelant est participant
    const myPart = await prisma.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: myId } },
    }).catch(() => null)

    // MSG-07 G3: vérifier que c'est le pro responsable
    const conv = await prisma.conversation.findUnique({ where: { id }, select: { projectId: true } })
    if (conv?.projectId) {
      const project = await prisma.project.findUnique({
        where: { id: conv.projectId },
        select: { ownerId: true },
      })
      if (project && project.ownerId !== myId) {
        return res.status(403).json({ error: 'Seul le professionnel responsable peut retirer des participants' })
      }
    }

    // Ne pas permettre de se retirer soi-même ni de retirer les participants originaux (1:1)
    if (userId === myId) {
      return res.status(400).json({ error: 'Utilisez la suppression de conversation pour quitter' })
    }

    await prisma.conversationParticipant.delete({
      where: { conversationId_userId: { conversationId: id, userId } },
    }).catch(() => {})

    // Notifier le participant retiré
    const io = getIo()
    if (io) {
      io.to(`user:${userId}`).emit('conversation:removed', { conversationId: id })
    }

    res.json({ ok: true })
  } catch (err) {
    next(err)
  }
})

// ─── Quitter / masquer une conversation (DELETE pour l'utilisateur courant) ───
router.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    const prisma = getPrisma()
    const userId = req.user.id
    const { id } = req.params
    // Retirer le participant — la conversation reste pour les autres
    await prisma.conversationParticipant.deleteMany({
      where: { conversationId: id, userId },
    })
    res.json({ ok: true })
  } catch (err) {
    next(err)
  }
})

module.exports = router
